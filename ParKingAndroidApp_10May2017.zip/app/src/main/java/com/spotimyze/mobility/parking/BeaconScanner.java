package com.spotimyze.mobility.parking;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import java.util.TreeSet;

/**
 * Created by S.Rajesh Kumar on 4/11/2017.
 */
public class BeaconScanner {
    private DataKey            dataKey;
    private BluetoothManager   btManager;
    private BluetoothAdapter   btAdapter;
    private BluetoothLeScanner btScanner;
    private TreeSet<Beacon>    bcnsInRng        = new TreeSet<Beacon>(new Beacon.BeaconComparator());
    private TreeSet<Beacon>    wantedBeacons    = null; // list of beacons user is interested in
    private String             logFileName      = "";
    private String             date             = "";
    private String             time             = "";
    private double             rcrdLat          = 0;
    private double             rcrdLon          = 0;
    private float              rcrdSpd          = 0;
    private boolean            wantLog          = false;
    private boolean            testLog          = false;
    private LogCounter         logCounter       = null;

    public BeaconScanner(DataKey dk, TreeSet<Beacon> bcns) {dataKey = dk; wantedBeacons = bcns;}
    public boolean init() {
        Context ctxt = dataKey.context(); logCounter = new LogCounter(); logCounter.count(0);
        btManager = (BluetoothManager)(ctxt.getSystemService(Context.BLUETOOTH_SERVICE));
        if(btManager == null) {
            Toast.makeText(ctxt, "no bluetooth manager, aborting scan", Toast.LENGTH_LONG).show();
            return(false);
        }

        btAdapter = btManager.getAdapter();
        if(btAdapter == null) {
            Toast.makeText(ctxt, "no bluetooth adapter, aborting scan", Toast.LENGTH_LONG).show();
            return(false);
        }

        btScanner = btAdapter.getBluetoothLeScanner();
        if(btScanner == null) {
            Toast.makeText(ctxt, "null scanner, aborting scan", Toast.LENGTH_LONG).show();
            return(false);
        }

        Toast.makeText(ctxt, "scanner initialized", Toast.LENGTH_SHORT).show();
        return(true);
    }

    public boolean startBleScan() {
        if(testLog == true) sndTestLogToSrvr();
        if(btScanner == null) return(false); btScanner.startScan(leScanCallback); return(true);
    }
    public void stopBleScan() {
        if(btScanner == null) return;
        btScanner.stopScan(leScanCallback);
        btScanner.flushPendingScanResults(leScanCallback);
    }
    public TreeSet<Beacon> beaconsInRange() {return(bcnsInRng);}
    public void clearBeaconsInRange() {if(bcnsInRng != null) bcnsInRng.clear();}

    private ScanCallback leScanCallback = new ScanCallback() {
        public void onScanResult(int callbackType, ScanResult result) {
        if(result ==null) return;
        ScanRecord scnRcrd = result.getScanRecord(); if(scnRcrd == null) return;
        String hwAddr = result.getDevice().getAddress(); if(hwAddr == null) hwAddr = "";
        byte[] scnRcrdBytes = scnRcrd.getBytes(); if(scnRcrdBytes == null) return;
        Beacon bcn = getBeaconInfo(scnRcrdBytes); if(bcn == null) return; // bad beaocn signal
        if(beaconWanted(bcn) == false) return; // does not match user-installed filter
        if(bcnsInRng.contains(bcn) == false) {
            bcnsInRng.add(bcn); bcn.rxRssi(result.getRssi()); bcn.hwAddr(hwAddr);
            if(wantLog == true) sndLogToSrvr(bcn);
        }
        }
    };

    private void sndLogToSrvr(Beacon bcn) {
        CmdHdlr ch = new CmdHdlr();
        String s = date + "," + time + "," + String.valueOf(rcrdLat) + "," + String.valueOf(rcrdLon)
            + "," + bcn.uuid() + "," + String.valueOf(bcn.majNum()) + ","
            + String.valueOf(bcn.minNum()) + "," + String.valueOf(bcn.txRssi()) + ","
            + String.valueOf(bcn.rxRssi()) + "," + bcn.hwAddr() + "," + String.valueOf(rcrdSpd);
        ch.writeLogToSrvr(dataKey, logFileName(), s, logCounter);
    }

    private void sndTestLogToSrvr() {
        final String uuid  = "ABCDABCDABCDABCDABCDABCDABCDABCD", hwAddr = "FF:EE:FF:EE:FF:EE";
        final int    mjNm   = 111, mnNm   = 222;
        final int    txRssi = -1, rxRssi = -1;
        CmdHdlr ch = new CmdHdlr();
        String s = "16-Jun-1974" + "," + "13:06:20" + "," + "1.23456" + "," + "9.87654" + ","
            + uuid + "," + String.valueOf(mjNm) + "," + String.valueOf(mnNm) + ","
            + String.valueOf(txRssi) + "," + String.valueOf(rxRssi) + ","
            + hwAddr + "," + String.valueOf(rcrdSpd);
        ch.writeLogToSrvr(dataKey, logFileName(), s, logCounter);
    }

    private Beacon getBeaconInfo(byte[] infoBytes) {
        int len = infoBytes.length; if(len < 30) return(null); // we need at least 30 bytes
        String s = bytesToHex(infoBytes); len = s.length();
        // 1st 4 characters must be 0201, check this
        // ignore 5th to 18th characters - 5th & 6th are flags; 7th to 18th are manufacturer data
        // 19th to 50th characters have the uuid (32 characters = 16 bytes)
        // 51st to 54th characters (26th & 27th bytes) have major-number (4 characters = 2 bytes)
        // 55th to 58th characters (28th & 29th bytes) have minor-number (4 characters = 2 bytes)
        // 59th and 60 characters (30th byte) has transmitted rssi (2 characters = 1 byte)
        if(s.substring(0, 4).equals("0201") == false) return(null);
        int mjr = ((infoBytes[25] & 0xff) * 0x100) + (infoBytes[26] & 0xff);
        int mnr = ((infoBytes[27] & 0xff) * 0x100) + (infoBytes[28] & 0xff);
        Beacon bcn = new Beacon("", s.substring(18, 50), mjr, mnr);
        int txRssi = (infoBytes[29] & 0xff) - 255; bcn.txRssi(txRssi);
        return(bcn);
    }

    public boolean beaconWanted(Beacon bcn) {
        if((wantedBeacons == null) || (wantedBeacons.isEmpty() == true)) return(true);
        if(wantedBeacons.contains(bcn) == true) return(true);
        return(false);
    }

    static final char[] hexArray = "0123456789ABCDEF".toCharArray();
    private static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for(int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4]; hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    public void   logFileName(String val)        {logFileName = val;}
    public void   date(String val)               {date        = val;}
    public void   time(String val)               {time        = val;}
    public void   rcrdLat(double val)            {rcrdLat     = val;}
    public void   rcrdLon(double val)            {rcrdLon     = val;}
    public void   rcrdSpd(float val)             {rcrdSpd     = val;}
    public void   wantLog(boolean val)           {wantLog     = val;}
    public void   testLog(boolean val)           {testLog     = val;}

    public String  logFileName()                 {return(logFileName);}
    public int     logCount()                    {return(logCounter.count());}
    public void    logCount(int val)             {logCounter.count(val);}

    public double calculateDistance(int txPower, double rssi) {
        if (rssi == 0) {return -1.0;} // if we cannot determine accuracy, return -1.
        double ratio = rssi*1.0/txPower;
        if (ratio < 1.0) {return Math.pow(ratio,10);}
        else {double accuracy =  (0.89976)*Math.pow(ratio,7.7095) + 0.111; return accuracy;}
    }
}
