package com.spotimyze.mobility.parking;

import android.graphics.Color;
import android.os.AsyncTask;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by S.Rajesh Kumar on 3/15/2017.
 */
    // A class to parse the Google Places in JSON format and draw polyline on map*/
public class RouteDisplayer extends AsyncTask<String, Integer, List<List<HashMap<String,String>>>> {
    private DataKey dataKey;
    public RouteDisplayer(DataKey dk) {dataKey = dk;}
    // parse the data in non-ui thread
    @Override
    protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {
        JSONObject jObject;
        List<List<HashMap<String, String>>> routes = null;
        try {
            jObject = new JSONObject(jsonData[0]);
            DirectionsJsonParser parser = new DirectionsJsonParser();
            routes = parser.parse(jObject); // Starts parsing data
        }
        catch(Exception e) {e.printStackTrace();}
        return routes;
    }

    @Override
    protected void onPostExecute(List<List<HashMap<String, String>>> result) {
        ArrayList<LatLng> points = null;
        PolylineOptions lineOptions = null;
        MarkerOptions markerOptions = new MarkerOptions();
        for(int i=0;i<result.size();i++){ // Traversing through all the routes
            points = new ArrayList<LatLng>();
            lineOptions = new PolylineOptions();
            List<HashMap<String, String>> path = result.get(i); // Fetching i-th route
            for(int j=0;j<path.size();j++){ // Fetching all the points in i-th route
                HashMap<String,String> point = path.get(j);
                double lat = Double.parseDouble(point.get("lat"));
                double lng = Double.parseDouble(point.get("lng"));
                LatLng position = new LatLng(lat, lng);
                points.add(position);
            }
            lineOptions.addAll(points); // add all points in route to LineOptions
            lineOptions.width(2);
            lineOptions.color(Color.RED);
        }
        dataKey.appMap().addPolyline(lineOptions); // draw polyline on Google Map for i-th route
    }
}
