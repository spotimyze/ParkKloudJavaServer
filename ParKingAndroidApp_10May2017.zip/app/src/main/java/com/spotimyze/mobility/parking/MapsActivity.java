package com.spotimyze.mobility.parking;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Semaphore;

/**
 * Created by S.Rajesh Kumar on 4/17/2017.
 */
public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener {

    private DataKey dataKey = new DataKey();
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        init();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        BcnFltrHdlr bfh = new BcnFltrHdlr();
        bleScnCtrlr = (TextView)(findViewById(R.id.bleScnCtrlr));
        bfh.drwBcnFltVw(dataKey, (LinearLayout)(findViewById(R.id.bcnNamesHldr)),
                                (LinearLayout)(findViewById(R.id.bcnInfoHldr)),
                                (ScrollView)(findViewById(R.id.bcnInfoCntnr)));
        readSavedProfile();
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapHldr);
        mapFragment.getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        dataKey.curMrkr(null); dataKey.appMap(googleMap);
        //dataKey.appMap().setMapType(GoogleMap.MAP_TYPE_HYBRID);
        (new LastLocnHdlr()).restoreSavedLocation(dataKey);
        String latStr = dataKey.curLat(), lonStr = dataKey.curLon();
        double lat = 42.361145, lon = -71.057083; // start at Boston by default
        if((latStr != null) && (latStr.isEmpty() == false) &&
           (lonStr != null) && (lonStr.isEmpty() == false)) {
            try {lat = Double.valueOf(latStr); lon = Double.valueOf(lonStr);}
            catch(NumberFormatException nfe) {lat = 42.361145; lon = -71.057083;}
        }
        dataKey.appMap().moveCamera(CameraUpdateFactory.newLatLng(new LatLng(lat, lon)));
        dataKey.appMap().animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 15));
        dataKey.newMrkrBmd(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW));
        dataKey.rgdMrkrBmd(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));

        dataKey.appMap().setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng point) {
                dataKey.appMap().moveCamera(CameraUpdateFactory.newLatLng(point));
                if(dataKey.curMrkr() != null) {
                    String tag = (String)(dataKey.curMrkr().getTag());
                    if((tag == null) || (tag.isEmpty() == true)) {
                        dataKey.curMrkr().remove(); dataKey.curMrkr(null);
                    }
                }
                if(dataKey.manageMode() == true) {
                    // place marker only if manageMode = true
                    MarkerOptions options = new MarkerOptions().position(point).icon(dataKey.newMrkrBmd());
                    options.title(getAddressFromLatLng(point));
                    dataKey.curMrkr(dataKey.appMap().addMarker(options)); dataKey.curMrkr().setTag("");
                    String addr = getAddressFromLatLng(point); if(addr == null) addr = "";
                    ((EditText)(findViewById(R.id.addrHldr))).setText(addr);
                }
                dataKey.curLat(String.valueOf(point.latitude));
                dataKey.curLon(String.valueOf(point.longitude));
                (new LastLocnHdlr()).saveLastLocation(dataKey);
            }
        });

        dataKey.appMap().setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker mrkr) {
                if(dataKey.manageMode() == false) {
                    SpotInfo spInf = dataKey.findParkSpot(mrkr); if(spInf == null) return(false);
                    dataKey.parkDst(spInf);
                    return(false);
                }
                if(dataKey.curMrkr() != null) {
                    String tag = (String)(dataKey.curMrkr().getTag());
                    if((tag == null) || (tag.isEmpty() == true)) {
                        dataKey.curMrkr().remove(); dataKey.curMrkr(null);
                    }
                }
                LatLng pos = mrkr.getPosition();
                dataKey.curMrkr(mrkr);
                dataKey.curLat(String.valueOf(pos.latitude));
                dataKey.curLon(String.valueOf(pos.longitude));
                return(false);
            }
        });

        mGoogleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
        mGoogleApiClient.connect();
        //updateMapDisplay(2.5); // we try to show map for a radius of 5 miles, by default
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        if(recordOn == true) {
            savedInstanceState.putBoolean("recordOn", true);
            if(bs == null) {
                savedInstanceState.putString("curLogFileName", "");
                savedInstanceState.putInt("logCount", 0);
            }
            else {
                savedInstanceState.putString("curLogFileName", bs.logFileName());
                savedInstanceState.putInt("logCount", bs.logCount());
            }
        }
        else {
            savedInstanceState.putBoolean("recordOn", false);
            savedInstanceState.putString("curLogFileName", "");
            savedInstanceState.putInt("logCount", 0);
        }
        savedInstanceState.putInt("curView", dataKey.curView());
        savedInstanceState.putString("edtBcnName", dataKey.edtBcnName());
        stopBleScan(null);
        dataKey.clear();
        super.onSaveInstanceState(savedInstanceState);
        Log.d("onSaveInstanceState: ", "curView " + savedInstanceState.getInt("curView"));
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        Log.d("onRestoreState: ", "curView " + savedInstanceState.getInt("curView"));
        super.onRestoreInstanceState(savedInstanceState);
        int lastVw = savedInstanceState.getInt("curView");
        if(lastVw == Util.MAIN_VW)             {}
        else if(lastVw == Util.HLP_VW)         {showHelp(null);}
        else if(lastVw == Util.PRF_VW)         {showProfile(null);}
        else if(lastVw == Util.BCNFLTR_VW)     {showBeaconFilter(null);}
        else if(lastVw == Util.MNGSPT_VW)      {showManageSpotsVw(null);}
        else if(lastVw == Util.FNDPRK_VW)      {showFindParkingVw(null);}
        else if(lastVw == Util.BCNINFOFLTR_VW) {
            String edtBcnName = savedInstanceState.getString("edtBcnName");
            if((edtBcnName != null) && (edtBcnName.isEmpty() == false)) {
                showBeaconFilter(null);
                BcnFltrHdlr bfh = new BcnFltrHdlr();
                bfh.showBeaconInfoVw(dataKey,edtBcnName,
                    (LinearLayout)(findViewById(R.id.bcnNamesHldr)),
                    (LinearLayout)(findViewById(R.id.bcnInfoHldr)),
                    (ScrollView)(findViewById(R.id.bcnInfoCntnr)));
                dataKey.edtBcnName(edtBcnName);

            }
        }
        else if(lastVw == Util.BCNINFORGN_VW)  {showBeaconForRegn(null);}
        boolean b = savedInstanceState.getBoolean("recordOn");
        if(b == true) startBleScanInner(null, savedInstanceState.getString("curLogFileName"),
                                                    savedInstanceState.getInt("logCount"));
    }

    @Override
    protected void onStop() {
        stopBleScan(null);
        if((mGoogleApiClient != null) && (continueLocnReqs == false)) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }
        if(mGoogleApiClient != null) {mGoogleApiClient.disconnect();}
        mGoogleApiClient = null;
        mLocationRequest = null;
        GoogleMap appMap = dataKey.appMap(); dataKey.clear(); if(appMap != null) appMap.clear();
        super.onStop();
    }

    private void init() {
        dataKey.context(this); dataKey.curMrkr(null); dataKey.lastLocnFile("lastLocn");
        dataKey.ocpdSpotFile("occupiedSpots"); dataKey.prfFile("profile");
        findScrnDimens(dataKey);
    }

    private String getAddressFromLatLng( LatLng latLng ) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        String address = "";
        try {address = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
                    .get( 0 ).getAddressLine( 0 );
        } catch (IOException e ) {}
        return address;
    }

    private void showManageCtrls() {
        dataKey.clrRegdSpots(); dataKey.clrParkSpots();
        (findViewById(R.id.registerClkr)).setVisibility(View.VISIBLE);
        (findViewById(R.id.withdrawClkr)).setVisibility(View.VISIBLE);
        (findViewById(R.id.atchBcnClkr)).setVisibility(View.VISIBLE);
        (findViewById(R.id.atchImgClkr)).setVisibility(View.VISIBLE);
        (findViewById(R.id.occupyClkr)).setVisibility(View.GONE);
        (findViewById(R.id.releaseClkr)).setVisibility(View.GONE);
        (findViewById(R.id.imgShwTrgr)).setVisibility(View.GONE);
        ((EditText)(findViewById(R.id.addrHldr))).setHint("address: 123 abc road state zip");
        EditText labelHldr = ((EditText)(findViewById(R.id.labelHldr)));
        LinearLayout.LayoutParams prms = (LinearLayout.LayoutParams)(labelHldr.getLayoutParams());
        prms.weight = 1.0f; labelHldr.setLayoutParams(prms);
        labelHldr.setHint("label - eg 23 / [1-100] / [B1, B2, B3][1-200]");
        (findViewById(R.id.rangeHldr)).setVisibility(View.GONE);
        (findViewById(R.id.dirnTrigger)).setVisibility(View.GONE);
        (findViewById(R.id.findTrigger)).setVisibility(View.GONE);
        dataKey.manageMode(true);
        (new CmdHdlr()).getRegisteredSpots(dataKey);
    }

    private void showFindParkingControls() {
        dataKey.clrRegdSpots(); dataKey.clrParkSpots();
        (findViewById(R.id.registerClkr)).setVisibility(View.GONE);
        (findViewById(R.id.withdrawClkr)).setVisibility(View.GONE);
        (findViewById(R.id.atchBcnClkr)).setVisibility(View.GONE);
        (findViewById(R.id.atchImgClkr)).setVisibility(View.GONE);
        (findViewById(R.id.occupyClkr)).setVisibility(View.VISIBLE);
        (findViewById(R.id.releaseClkr)).setVisibility(View.VISIBLE);
        (findViewById(R.id.imgShwTrgr)).setVisibility(View.VISIBLE);
        ((EditText)(findViewById(R.id.addrHldr))).setHint("address: 123 abc road state zip");
        EditText labelHldr = ((EditText)(findViewById(R.id.labelHldr)));
        LinearLayout.LayoutParams prms = (LinearLayout.LayoutParams)(labelHldr.getLayoutParams());
        prms.weight = 0.5f; labelHldr.setLayoutParams(prms);
        labelHldr.setHint("label - eg 2 / B45");
        (findViewById(R.id.rangeHldr)).setVisibility(View.VISIBLE);
        (findViewById(R.id.dirnTrigger)).setVisibility(View.VISIBLE);
        (findViewById(R.id.findTrigger)).setVisibility(View.VISIBLE);
        dataKey.manageMode(false);
    }

    public void goToAddr(View vw) {
        EditText addrHldr = (EditText)(findViewById(R.id.addrHldr));
        String addrStr = addrHldr.getText().toString();
        if((addrStr == null) || (addrStr.isEmpty() == true)) return;
        LatLng addrPos = getLocationFromAddress(dataKey.context(), addrStr);
        if(addrPos == null) {Log.d("LOG: ", "unable to fetch position."); return;}
        if(dataKey.curMrkr() != null) {
            String tag = (String)(dataKey.curMrkr().getTag());
            if((tag == null) || (tag.isEmpty() == true)) {
                dataKey.curMrkr().remove(); dataKey.curMrkr(null);
            }
        }
        dataKey.appMap().moveCamera(CameraUpdateFactory.newLatLng(addrPos));
        dataKey.curLat(String.valueOf(addrPos.latitude));
        dataKey.curLon(String.valueOf(addrPos.longitude));
        (new LastLocnHdlr()).saveLastLocation(dataKey);
        if(dataKey.manageMode() == true) {
            dataKey.curMrkr(dataKey.appMap().addMarker(new MarkerOptions().position(addrPos)
                    .icon(dataKey.newMrkrBmd()).title(addrStr)));
        }
    }

    public void getDirns(View vw) {
        String ltS = dataKey.curLat(), lnS = dataKey.curLon();
        if((ltS == null) || (ltS.isEmpty() == true) || (lnS == null) || (lnS.isEmpty() == true))
            return;
        double lat, lon;
        try {lat = Double.valueOf(dataKey.curLat()); lon = Double.valueOf(dataKey.curLon());}
        catch(NumberFormatException nfe) {return;}
        LatLng p1 = new LatLng(lat, lon);
        SpotInfo spInf = dataKey.parkDst(); if(spInf == null) return;
        Marker m = spInf.mrkr(); if(m == null) return;
        LatLng p2 = m.getPosition();  if(p2 == null) return;
        String params = "origin=" + p1.latitude + "," + p1.longitude + "&" + "destination="
                + p2.latitude + "," + p2.longitude + "&" + "sensor=false";
        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/json?" + params;
        RouteFinder rf = new RouteFinder(dataKey); rf.execute(url);
    }

    public void getDirnsWithGoogleMaps(View vw) {
        SpotInfo spInf = dataKey.parkDst();
        if(spInf == null) {
            Toast.makeText(this, "no parking spot selected", Toast.LENGTH_LONG).show(); return;
        }
        double lat = spInf.lat(), lon = spInf.lon();
        String dstUri = "google.navigation:q=" + String.valueOf(lat) + "," + String.valueOf(lon);
        Intent brwsrIntnt = new Intent(Intent.ACTION_VIEW, Uri.parse(dstUri));
        startActivity(brwsrIntnt);
    }

    public void registerSpots(View vw) {
        String addr  = ((EditText)(findViewById(R.id.addrHldr))).getText().toString();
        if(addr == null) addr = "";
        String label = ((EditText)(findViewById(R.id.labelHldr))).getText().toString();
        (new CmdHdlr()).registerSpot(dataKey, addr, label);
    }

    public void withdrawSpots(View vw) {(new CmdHdlr()).withdrawSpot(dataKey);}

    public void findSpots(View vw) {
        String rs = ((EditText)(findViewById(R.id.rangeHldr))).getText().toString().trim();
        (new CmdHdlr()).findSpots(dataKey, rs);
    }

    public void occupySpot(View vw)    {
        String label = ((EditText)(findViewById(R.id.labelHldr))).getText().toString();
        if(label == null) label = "";
        (new CmdHdlr()).occupySpot(dataKey, label);
    }
    public void releaseSpot(View vw)   {(new CmdHdlr()).releaseSpot(dataKey);}

    public void getImageForSpot(View vw) {
        SpotInfo spInf  = dataKey.parkDst(); if(spInf == null) return;
        String imgFile = spInf.imgFile(); if((imgFile == null) || (imgFile.isEmpty() == true)) {
            Log.d("IMG-DWNL-LOG:", "cant find imgFile"); return;
        }
        ImageDownloader imgDndr = new ImageDownloader(dataKey.context());
        imgDndr.downloadFile(imgFile, findViewById(R.id.parkSpotImgVwHldr),
            findViewById(R.id.mngAndFndVwHldr), findViewById(R.id.parkSpotImgVw));
    }

    public void showHelp(View vw) {
        ((TextView)(findViewById(R.id.hlpTxtHldr))).setText(HelpText.hlpTxt);
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.GONE);
        (findViewById(R.id.hlpVwHldr)).setVisibility(View.VISIBLE);
        dataKey.curView(Util.HLP_VW);
    }

    public void hideHelp(View vw) {
        ((TextView)(findViewById(R.id.hlpTxtHldr))).setText("");
        (findViewById(R.id.hlpVwHldr)).setVisibility(View.GONE);
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.VISIBLE);
        dataKey.curView(Util.MAIN_VW);
    }

    public void showProfile(View vw) {
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.GONE);
        (findViewById(R.id.prfVw)).setVisibility(View.VISIBLE);
        dataKey.curView(Util.PRF_VW);
    }

    public void hideProfile(View vw) {
        (findViewById(R.id.prfVw)).setVisibility(View.GONE);
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.VISIBLE);
        dataKey.curView(Util.MAIN_VW);
    }

    public void showBeaconFilter(View vw) {
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.GONE);
        (findViewById(R.id.bcnFltrVw)).setVisibility(View.VISIBLE);
        dataKey.curView(Util.BCNFLTR_VW);
    }

    public void hideBeaconFilter(View vw) {
        (findViewById(R.id.bcnFltrVw)).setVisibility(View.GONE);
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.VISIBLE);
        dataKey.curView(Util.MAIN_VW);
    }

    public void showManageSpotsVw(View vw) {
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.GONE);
        (findViewById(R.id.mngAndFndVwHldr)).setVisibility(View.VISIBLE);
        showManageCtrls();
        dataKey.curView(Util.MNGSPT_VW);
    }

    public void hideMngAndFndVw(View vw) {
        (findViewById(R.id.mngAndFndVwHldr)).setVisibility(View.GONE);
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.VISIBLE);
        dataKey.curView(Util.MAIN_VW);
    }

    public void showFindParkingVw(View vw) {
        (findViewById(R.id.mainMenuHldr)).setVisibility(View.GONE);
        (findViewById(R.id.mngAndFndVwHldr)).setVisibility(View.VISIBLE);
        showFindParkingControls();
        dataKey.curView(Util.FNDPRK_VW);
    }

    public void showBeaconForRegn(View vw) {
        ScrollView bcnInfoCntnr = (ScrollView)(findViewById(R.id.bcnInfoCntnr));
        LinearLayout mngAndFndVw = (LinearLayout) (findViewById(R.id.mngAndFndVwHldr));
        mngAndFndVw.setVisibility(View.GONE);
        bcnInfoCntnr.setVisibility(View.VISIBLE);
        bcnInfoCntnr.setTag("beaconForRegistration");
        BcnSlctnPopulator bsp = new BcnSlctnPopulator(dataKey,
            (LinearLayout)(findViewById(R.id.bcnInfoHldr)));
        bsp.populateNearbyBeaconsList();
        dataKey.curView(Util.BCNINFORGN_VW);
    }

    public void attachImgForRegn(View vw) {
        CmdHdlr ch = new CmdHdlr(); ch.getImagesDir(dataKey);
        Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(pickPhoto, 1); // use any integer not just 1
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
            if(resultCode == RESULT_OK){
                Marker mrkr = dataKey.curMrkr(); if(mrkr == null) return;
                Uri selectedImage = imageReturnedIntent.getData();
                String[] projection = {MediaStore.MediaColumns.DATA};
                Cursor cursor = getContentResolver().query(selectedImage, projection, null, null, null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
                cursor.moveToFirst();
                String imagePath = cursor.getString(column_index);

                dataKey.imgFile(imagePath);
                String extn = null;
                if(imagePath.endsWith(".bmp")       == true) extn = ".bmp";
                else if(imagePath.endsWith(".jpeg") == true) extn = ".jpeg";
                else if(imagePath.endsWith(".jpg")  == true) extn = ".jpg";
                else if(imagePath.endsWith(".png")  == true) extn = ".png";
                String imgsDir = dataKey.imgsDir();
                String spotId  = (String)(mrkr.getTag());
                if((imgsDir != null) && (imgsDir.isEmpty() == false) &&
                   (spotId != null)  && (spotId.isEmpty() == false) && (extn != null)) {
                    String remoteFile = imgsDir + "/" + spotId + extn;
                    ImageUploader imgUpldr = new ImageUploader(dataKey.context());
                    imgUpldr.uploadFile(imagePath, remoteFile);
                    CmdHdlr ch = new CmdHdlr();
                    ch.addImageToSpot(dataKey, spotId, remoteFile);
                    Toast.makeText(this, "image file added to parking spot", Toast.LENGTH_LONG).show();
                }
            }
    }

    public void addNewBeaconFilterRow(View vw) {
        (new BcnFltrHdlr()).addNewBeaconFilterRow(dataKey,
            (LinearLayout)(findViewById(R.id.bcnNamesHldr)),
            (LinearLayout)(findViewById(R.id.bcnInfoHldr)),
            (ScrollView)(findViewById(R.id.bcnInfoCntnr)), null);
    }

    public void removeBeaconFilterRows(View vw) {
        (new BcnFltrHdlr()).removeBeaconFilterRows(dataKey,
                (LinearLayout)(findViewById(R.id.bcnNamesHldr)));
    }

    public void saveWantedBeacons(View vw) {
        (new BcnFltrHdlr()).saveWantedBeacons(dataKey);
    }

    public void hideBeaconInfoVw(View vw) {
        ScrollView bcnInfoCntnr = (ScrollView)(findViewById(R.id.bcnInfoCntnr));
        String tg = (String)(bcnInfoCntnr.getTag()); if(tg == null) return;
        LinearLayout bcnInfoHldr = (LinearLayout)(findViewById(R.id.bcnInfoHldr));
        if(tg.equals("beaconForRegistration") == true) {
            bcnInfoCntnr.setVisibility(View.GONE);
            (findViewById(R.id.mngAndFndVwHldr)).setVisibility(View.VISIBLE);
            dataKey.regnBeacon((new BcnFltrHdlr()).readBeaconInfoFrmVw(bcnInfoHldr));
            dataKey.curView(Util.MNGSPT_VW);
        }
        else if(tg.equals("beaconForFilter") == true) {
            (new BcnFltrHdlr()).hideBeaconInfoVw((LinearLayout)(findViewById(R.id.bcnNamesHldr)),
                                                           bcnInfoHldr, dataKey, bcnInfoCntnr);
            dataKey.curView(Util.BCNFLTR_VW);
        }
        bcnInfoCntnr.setTag("");
    }

    public void hideParkSpotImage(View vw) {
        (findViewById(R.id.parkSpotImgVwHldr)).setVisibility(View.GONE);
        (findViewById(R.id.mngAndFndVwHldr)).setVisibility(View.VISIBLE);
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        try {dataKey.appMap().setMyLocationEnabled(true);}
        catch(SecurityException se) {Log.d("LOG: ", "security exception - can't get current location"); return;}
        mLocationRequest = new LocationRequest();
        makeLocationRequest(1000);
    }

    private void makeLocationRequest(long intrvl) {
        if(mLocationRequest == null) return;
        mLocationRequest.setInterval(intrvl);
        mLocationRequest.setFastestInterval(intrvl);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        if(ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }
    }

    @Override public void onConnectionSuspended(int i) {}

    @Override
    public void onLocationChanged(Location locn) {
        if(locn == null) return;
        LatLng latLng = new LatLng(locn.getLatitude(), locn.getLongitude());
        if(latLng == null) return;
        if(recordOn == false) {
            dataKey.appMap().moveCamera(CameraUpdateFactory.newLatLng(latLng));
            dataKey.appMap().animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
            //String addr = getAddressFromLatLng(latLng);
            //if (addr == null) addr = "";
            //((EditText)(findViewById(R.id.addrHldr))).setText(addr);
            ((EditText)(findViewById(R.id.addrHldr))).setText("");
        }
        rcrdLat = locn.getLatitude(); rcrdLon = locn.getLongitude(); rcrdSpd = locn.getSpeed();

        ////stop location updates
        if((mGoogleApiClient != null) && (continueLocnReqs == false)) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
        }
        //updateMapDisplay(2.5);
    }

    @Override public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.d("spotimyze ParKing: ", "connectionFailed");
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    @Override
    public void onRequestPermissionsResult(int requestCode,
            String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if(grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted. Do the contacts-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            android.Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {
                        //if (mGoogleApiClient == null) {buildGoogleApiClient();}
                        //dataKey.appMap().setMyLocationEnabled(true);
                    }

                } else {Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();}
                return;
            }
        }
    }

    public LatLng getLocationFromAddress(Context context, String addrStr) {
        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            address = coder.getFromLocationName(addrStr, 5);
            if((address == null) || (address.isEmpty() == true)) {return null;}
            Address location = address.get(0); location.getLatitude(); location.getLongitude();
            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {ex.printStackTrace();}
        return(p1);
    }

    public  void saveProfile(View vw) {(new PrfHdlr()).saveProfile(dataKey);}
    private void readSavedProfile()   {(new PrfHdlr()).readSavedProfile(dataKey);}

    private void findScrnDimens(DataKey dataKey) {
        WindowManager wm = (WindowManager)(dataKey.context().getSystemService(Context.WINDOW_SERVICE));
        Display display = wm.getDefaultDisplay();
        Point size = new Point(); display.getSize(size);
        dataKey.scrnWidth(size.x); dataKey.scrnHeight(size.y);
    }

    //private void updateMapDisplay(double sqLen) {
    //    if(sqLen <= 0) sqLen = 2.5; // we try to show map for a radius of 5 miles, by default
    //    double lat = Double.valueOf(dataKey.curLat()), lon = Double.valueOf(dataKey.curLon());
    //    double scrnWid = dataKey.scrnWidth();
    //    double latAdj = Math.cos(Math.PI * lat / 180.0 );
    //    double arg = 24901.445310484 * scrnWid * latAdj / (sqLen * 256.0);
    //    double zoomLevel = Math.log(arg) / Math.log(2.0);
    //   dataKey.appMap().animateCamera(CameraUpdateFactory.
    //        newLatLngZoom(new LatLng(lat, lon), (float)(zoomLevel)));
    //}

    private Handler       rcrdHdlr       = new Handler();
    private boolean       recordOn       = false;
    private boolean       btScanOn       = false;
    private long          btScnIntrvl    = 1000; // ms
    private long          btScnOffIntrvl = btScnIntrvl / 10; // ms
    private long          btScnOnIntrvl  = btScnIntrvl - btScnOffIntrvl; // ms
    private BeaconScanner bs             = null;
    private TextView      bleScnCtrlr;
    private double        rcrdLat, rcrdLon;
    private float         rcrdSpd;
    private Semaphore     mtx = new Semaphore(1);
    private String        logHdr =
                          "date,time,latitude,longitude,uuid,major,minor,txrssi,rxrssi,hwAddr,speed";
    private boolean       continueLocnReqs = false;
    private boolean       testLog = true;

    public void startBleScan(View vw) {startBleScanInner(vw, null, 0);}
    public void startBleScanInner(View vw, String logFileName, int logCount) {
        try {mtx.acquire();} catch(InterruptedException ie) {return;}
        if((bs != null) || (recordOn == true) || (btScanOn == true)) {mtx.release(); return;}
        bs = new BeaconScanner(dataKey, dataKey.wantedBeacons());
        boolean res = bs.init(); bs.wantLog(true); bs.testLog(testLog);
        // if(res == false) {bs = null; return;}
        bleScnCtrlr.setText("Stop recording");
        bleScnCtrlr.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View arg0) {stopBleScan(arg0);}
        });
        recordOn         = true;
        btScanOn         = false;
        continueLocnReqs = true;
        String usrId = ((EditText)(findViewById(R.id.usrIdHldr))).getText().toString();
        if((logFileName == null) || (logFileName.isEmpty() == true)) {
            bs.logFileName(Util.genLogFileName(usrId));
            (new CmdHdlr()).writeLogToSrvr(dataKey, bs.logFileName(), logHdr, null);
        }
        else {bs.logFileName(logFileName); if(logCount > 0) bs.logCount(logCount);}
        try {
            btScnIntrvl =
                Long.valueOf(((EditText)(findViewById(R.id.rcdIntvlHldr))).getText().toString());
            if(btScnIntrvl < 1000) btScnIntrvl = 1000;
        } catch(NumberFormatException nfe) {btScnIntrvl = 1000;}
        btScnOffIntrvl = btScnIntrvl / 10;
        btScnOnIntrvl  = btScnIntrvl - btScnOffIntrvl;
        makeLocationRequest(btScnOnIntrvl);
        rcrdHdlr.post(recorder);
        mtx.release();
    }

    public void stopBleScan(View vw) {
        try {mtx.acquire();} catch(InterruptedException ie) {return;}
        if((bs == null) || (recordOn == false)) {mtx.release(); return;}
        recordOn         = false;
        continueLocnReqs = false;
        bs.wantLog(false); bs.testLog(false);
        mtx.release();
    }

    private Runnable recorder = new Runnable() {
        @Override
        public void run() {
            try {mtx.acquire();} catch(InterruptedException ie) {return;}
            if(recordOn == true) {
                if(btScanOn == true) {
                    btScanOn = false; if(bs != null) bs.stopBleScan();
                    rcrdHdlr.postDelayed(this, btScnOffIntrvl);
                }
                else {
                    if(bs != null) {
                        bs.clearBeaconsInRange();
                        bs.date(Util.getDate()); bs.time(Util.getTime());
                        bs.rcrdLat(rcrdLat);     bs.rcrdLon(rcrdLon); bs.rcrdSpd(rcrdSpd);
                        bs.startBleScan();
                        int logCount = bs.logCount();
                        if(logCount > 0)
                            bleScnCtrlr.setText("Stop recording (" + String.valueOf(logCount) + ")");
                    }
                    btScanOn = true;
                    rcrdHdlr.postDelayed(this, btScnOnIntrvl);
                }
            }
            else {
                if(btScanOn == true) {btScanOn = false; if(bs != null) bs.stopBleScan();}
                bs = null;
                bleScnCtrlr.setText("Record");
                bleScnCtrlr.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View arg0) {startBleScan(arg0);}
                });
            }
            mtx.release();
        }
    };
}
