package com.spotimyze.mobility.parking;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by S.Rajesh Kumar on 3/15/2017.
 */
public class InFileHdlr {
    private InputStream isr;
    private BufferedReader br;
    private String         fnm;

    public InFileHdlr() {init();}
    private void init() {fnm = null; isr = null; br = null;}

    public boolean open(Context ctxt, String nm) {
        if((nm == null) || (nm.isEmpty() == true)) return(false);
        File inf = new File(ctxt.getFilesDir(), nm);
        if(inf == null) {return(false);}

        if(inf.exists() == false) {init(); return(false);}

        try {isr = new FileInputStream(inf);} catch(FileNotFoundException e) {init(); return(false);}
        if(isr == null) return(false);

        br = new BufferedReader(new InputStreamReader(isr));
        if(br == null) {
            try{isr.close();} catch(IOException e) {}
            init(); return(false);
        }

        fnm = nm;
        return (true);
    }

    public void close() {
        try {if(br != null) br.close(); if(isr != null) isr.close();} catch(IOException e) {}
        init();
    }

    public String getNextLine () {
        if(br == null) return(null);
        try{String str = br.readLine(); return(str);} catch(IOException e) {return(null);}
    }
}
