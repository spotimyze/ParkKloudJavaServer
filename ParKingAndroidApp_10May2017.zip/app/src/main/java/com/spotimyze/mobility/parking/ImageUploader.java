package com.spotimyze.mobility.parking;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.Charset;

/**
 * Created by S.Rajesh Kumar on 4/18/2017.
 */
public class ImageUploader {
    private Socket              sockToSrvr;
    private OutputStream        strmToSrvr;
    private BufferedInputStream strmFromSrvr;
    private String              srvrAddr;
    private int                 port;
    private String              localFile;
    private String              remoteFile;
    private Context             ctxt;
    private String              srvrRsp;

    public ImageUploader(Context c) {
        srvrAddr     = KloudSrvr.srvrIp();
        port         = KloudSrvr.port();
        sockToSrvr   = null;
        strmFromSrvr = null;
        strmToSrvr   = null;
        localFile    = null;
        remoteFile   = null;
        ctxt         = c;
        srvrRsp      = null;
    }

    public void uploadFile(String locf, String remf) {
        localFile = locf; remoteFile = remf;

        Thread uplThrd = new Thread() {
            @Override
            public void run() {
                openServerConnection(); doUpload(); readSrvrResponse(); closeServerConnection();
                ((Activity)ctxt).runOnUiThread(new Runnable() {
                    public void run() {
                        if(srvrRsp != null) {Toast.makeText(ctxt, srvrRsp, Toast.LENGTH_LONG).show();}
                    }
                });
            }
        };

        uplThrd.start();
    }

    private void doUpload() {
        if(strmToSrvr == null) return;
        File inFile = new File(localFile); if(inFile == null) return;
        long len = inFile.length();        if(len < 0) return;
        FileInputStream flis;
        try {flis = new FileInputStream(inFile);}
        catch(FileNotFoundException fnfe) {return;}
        if(flis == null) {return;};

        String hdr = "POST /" + srvrAddr + "/-size/" + String.valueOf(len)
                + "/-uploadFile/" + remoteFile + " HTTP/1.1\r\n\r\n"
                + "Host: " + srvrAddr + ":" + String.valueOf(port) + "\r\n"
                + "Connection: keep-alive\r\n"
                + "Content-Length: " + String.valueOf(len) + "\r\n"
                + "User-Agent: Spotimyze ParKing\r\n"
                + "Origin: http://" + srvrAddr + ":" + String.valueOf(port) + "\r\n"
                + "Accept: */*\r\n"
                + "Referer: http://" + srvrAddr + ":"
                + String.valueOf(port) + "/ParkKloud\r\n"
                + "Accept-Encoding: jpg, png\r\n"
                + "Accept-Language: en-US,en;q=0.8\r\n\r\n";

        byte[] hdrBytes = hdr.getBytes(Charset.forName("UTF-8"));
        try {strmToSrvr.write(hdrBytes);} catch(IOException ie) {return;}

        int chnkSz = 1024, avlByts, toRdByts, rdByts;
        while(true) {
            try {
                avlByts = flis.available(); if(avlByts <= 0) break;
                toRdByts = (avlByts < chnkSz) ? avlByts : chnkSz;
                byte[] byts = new byte[toRdByts];
                rdByts = flis.read(byts); if(rdByts <= 0) break;
                strmToSrvr.write(byts);
            }
            catch(IOException ie) {break;}
        }
        try {strmToSrvr.flush();} catch(IOException ie) {}
    }

    private void readSrvrResponse() {
        srvrRsp = "";
        int    mxBfSz = 1024, avlByts, toRdByts;

        while(true) {
            try {
                avlByts = strmFromSrvr.available(); if(avlByts <= 0) break;
                toRdByts = (avlByts < mxBfSz) ? avlByts : mxBfSz;
                byte[] byts = new byte[toRdByts];
                strmFromSrvr.read(byts);
                srvrRsp += new String(byts);
            } catch(IOException e) {srvrRsp = null; return;}
        }

        if((srvrRsp != null) && (srvrRsp.isEmpty() == false)) {
            String s1 = "<success>", s2 = "</success>", s3 = "<error>", s4 = "</error>";
            int p1 = srvrRsp.indexOf("s1"), p2 = -1;
            if(p1 < 0) {
                p1 = srvrRsp.indexOf(s3);              if(p1 < 0) {srvrRsp = null; return;}
                p2 = srvrRsp.indexOf(s4, s3.length()); if(p2 < 0) {srvrRsp = null; return;}
                srvrRsp = srvrRsp.replace(s3, "").replace(s4, "").trim();
            }
            else {
                p2 = srvrRsp.indexOf(s2, s1.length()); if(p2 < 0) {srvrRsp = null; return;}
                srvrRsp = srvrRsp.replace(s1, "").replace(s2, "").trim();
            }
        }
    }

    private void closeServerConnection() {
        if(sockToSrvr == null) return;
        if(strmFromSrvr != null) {
            try {strmFromSrvr.close();}
            catch(IOException e) {System.out.println("Inp strm close exception");}
        }
        if(strmToSrvr != null) {
            try {strmToSrvr.close();}
            catch(IOException e) {System.out.println("Op strm close exception");}
        }
        try {sockToSrvr.close();}
        catch(IOException e) {System.out.println("Conn close exception");}
        strmFromSrvr = null; strmToSrvr   = null; sockToSrvr   = null;
    }

    private void openServerConnection() {
        try {sockToSrvr = new Socket(InetAddress.getByName(srvrAddr), port);}
        catch(UnknownHostException e) {
            System.out.println("Unknown host exception"); sockToSrvr = null; return;
        } catch(IOException e) {
            System.out.println("Server connect exception"); sockToSrvr = null; return;
        }
        System.out.println("Connected to server");

        try {
            strmFromSrvr = new BufferedInputStream(sockToSrvr.getInputStream());
            strmToSrvr = sockToSrvr.getOutputStream();
        } catch(IOException e) {
            closeServerConnection();
            System.out.println("Failed to open reader / writer. Closed the connection."); return;
        }
    }
}
