package com.spotimyze.mobility.parking;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.TreeSet;

/**
 * Created by S.Rajesh Kumar on 4/15/2017.
 */
public class BcnSlctnPopulator {
    private BeaconScanner bs          = null;
    private DataKey       dataKey     = null;
    private LinearLayout  bcnSlctr    = null;
    private LinearLayout  bcnInfoHldr = null;
    TreeSet<Beacon> tstBcns           = new TreeSet<Beacon>(new Beacon.BeaconComparator());
    private Handler h                 = new Handler();

    public BcnSlctnPopulator(DataKey dk, LinearLayout beaconInfoHandler) {
        dataKey = dk; bcnInfoHldr = beaconInfoHandler; bcnSlctr = bcnInfoHldr;
        for(int c = 0, cs = bcnInfoHldr.getChildCount(); c < cs; c++) {
            View vw = bcnInfoHldr.getChildAt(c);
            if(vw.getId() == R.id.bcnSlctr) {bcnSlctr = (LinearLayout)vw; break;}
        }
    }

    public void populateNearbyBeaconsList() {
        if((bcnSlctr == null) || (dataKey == null)) {Log.d("LOG: ", "null input to populate"); return;}
        bs = new BeaconScanner(dataKey, dataKey.wantedBeacons()); bs.wantLog(false);
        boolean res = bs.init(); //if(res == false) {bs = null; return;}
        if(bs != null) bs.startBleScan();
        h.postDelayed(bcnFinder, 5000);
    }

    Runnable bcnFinder = new Runnable() {
        @Override public void run() {
            if(bs != null) bs.stopBleScan();
            TreeSet<Beacon> bcns = bs.beaconsInRange();
            Log.d("POPULATOR: ", "got beacons " + bcns.size());
            //setupTstBcns(); bcns = tstBcns;
            Activity acvty = ((Activity)dataKey.context()); if(acvty == null) return;
            acvty.runOnUiThread(new Runnable() {public void run() {addFoundBcnsToSlctnLst();}});
            bs.clearBeaconsInRange();
        }
    };

    private void addFoundBcnsToSlctnLst() {
        Context ctxt = dataKey.context(); if(ctxt == null) return;
        while(bcnSlctr.getChildCount() > 1) {bcnSlctr.removeView(bcnSlctr.getChildAt(1));}
        if(bs == null) return;
        TreeSet<Beacon> bcns = bs.beaconsInRange();
        Log.d("POPULATOR: ", "got beacons " + bcns.size());
        for(Beacon bcn : bcns) {
            String sep = "", uuid = "";
            for (int p = 0, c = 0; p < 8; p++, c += 4) {
                uuid += sep + bcn.uuid().substring(c, c + 4); sep = "-";
            }
            TextView tv = new TextView(ctxt);
            tv.setText(uuid + ":" + String.valueOf(bcn.majNum()) + ":" + String.valueOf(bcn.minNum()));
            tv.setClickable(true);
            tv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View arg0) {
                String bcnInfoStr = ((TextView) (arg0)).getText().toString();
                fillBcnInfo(bcnInfoStr);
                }
                });
            bcnSlctr.addView(tv);
        }
    }

    private void fillBcnInfo(String bcnInfoStr) {
        String[] parts = bcnInfoStr.split(":"); if (parts.length != 3) return;
        String uuid = parts[0], mjNm = parts[1], mnNm = parts[2];
        parts = uuid.split("-"); if(parts.length != 8) return;
        for(int c1 = 0, cs1 = bcnInfoHldr.getChildCount(); c1 < cs1; c1++) {
            View vw = bcnInfoHldr.getChildAt(c1);
            if(vw.getId() == R.id.majNumHldr)      {((EditText)vw).setText(mjNm);}
            else if(vw.getId() == R.id.minNumHldr) {((EditText)vw).setText(mnNm);}
            else if(vw.getId() == R.id.uuidHldr) {
                LinearLayout ll = (LinearLayout)vw;
                for(int c2 = 0, cs2 = ll.getChildCount(); c2 < cs2; c2++) {
                    View v2 = ll.getChildAt(c2);
                    int id = v2.getId();
                    if(id == R.id.uuidHldr1)      ((EditText)v2).setText(parts[0]);
                    else if(id == R.id.uuidHldr2) ((EditText)v2).setText(parts[1]);
                    else if(id == R.id.uuidHldr3) ((EditText)v2).setText(parts[2]);
                    else if(id == R.id.uuidHldr4) ((EditText)v2).setText(parts[3]);
                    else if(id == R.id.uuidHldr5) ((EditText)v2).setText(parts[4]);
                    else if(id == R.id.uuidHldr6) ((EditText)v2).setText(parts[5]);
                    else if(id == R.id.uuidHldr7) ((EditText)v2).setText(parts[6]);
                    else if(id == R.id.uuidHldr8) ((EditText)v2).setText(parts[7]);
                }
            }
        }
    }

    private void setupTstBcns() {
        tstBcns.clear();
        tstBcns.add(new Beacon("a", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 111, 111));
        tstBcns.add(new Beacon("b", "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB", 222, 222));
        tstBcns.add(new Beacon("c", "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC", 333, 333));
        tstBcns.add(new Beacon("d", "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD", 444, 444));
    }
}
