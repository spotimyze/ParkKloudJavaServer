package com.spotimyze.mobility.parking;

import android.app.Activity;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by S.Rajesh Kumar on 4/23/2017.
 */
public class PrfHdlr {
    public void saveProfile(DataKey dataKey) {
        String fl = dataKey.prfFile();
        if((fl == null) || (fl.isEmpty() == true)) {
            Log.d("LOG: ", "no profile filename defined, unable to save profile");
            return;
        }

        Activity avty = (Activity)(dataKey.context());
        String usrId  = ((EditText)(avty.findViewById(R.id.usrIdHldr))).getText().toString();
        String phone  = ((EditText)(avty.findViewById(R.id.phNumHldr))).getText().toString();
        String ccard  = ((EditText)(avty.findViewById(R.id.crCardHldr))).getText().toString();
        String bnkac  = ((EditText)(avty.findViewById(R.id.bnkAcHldr))).getText().toString();
        String rcInvl = ((EditText)(avty.findViewById(R.id.rcdIntvlHldr))).getText().toString();

       String s = "";
        if((usrId != null)  && (usrId.isEmpty() == false))  s += "usrId: "    + usrId  + "\r\n";
        if((phone != null)  && (phone.isEmpty() == false))  s += "phone: "    + phone  + "\r\n";
        if((ccard != null)  && (ccard.isEmpty() == false))  s += "ccard: "    + ccard  + "\r\n";
        if((bnkac != null)  && (bnkac.isEmpty() == false))  s += "bnkac: "    + bnkac  + "\r\n";
        if((rcInvl != null) && (rcInvl.isEmpty() == false)) s += "rcdIntvl: " + rcInvl + "\r\n";

        if((s == null) || (s.isEmpty() == true)) return;

        OutFileHdlr ofh = new OutFileHdlr();
        if(ofh.open(dataKey.context(), fl, false) == false) {
            Log.d("LOG: ", "unable to open file to save user profile");
            return;
        }
        ofh.writeLine(s);
        Log.d("LOG: ", "successfully saved profile");
        Toast.makeText(dataKey.context(), "profile saved", Toast.LENGTH_LONG).show();
        ofh.close();
    }

    public void readSavedProfile(DataKey dataKey) {
        String fl = dataKey.prfFile();
        if((fl == null) || (fl.isEmpty() == true)) {
            Log.d("LOG: ", "no profile file to save into");
            return;
        }
        InFileHdlr ifh = new InFileHdlr();
        if(ifh.open(dataKey.context(), fl) == false) {
            Log.d("LOG: ", "unable to profile file to save into");
            return;
        }
        String usrId = "", phone = "", ccard = "", bnkac = "", rcInvl = "";
        while (true) {
            String inLine = ifh.getNextLine(); if(inLine == null) break;
            if(inLine.isEmpty() == true) continue;
            if(inLine.trim().startsWith("usrId:") == true)
                usrId = inLine.replace("usrId:", "").trim();
            else if(inLine.trim().startsWith("phone:") == true)
                phone = inLine.replace("phone:", "").trim();
            else if(inLine.trim().startsWith("ccard:") == true)
                ccard = inLine.replace("ccard:", "").trim();
            else if(inLine.trim().startsWith("bnkac:") == true)
                bnkac = inLine.replace("bnkac:", "").trim();
            else if(inLine.trim().startsWith("rcdIntvl:") == true)
                rcInvl = inLine.replace("rcdIntvl:", "").trim();
        }
        ifh.close();

        String s = "";
        Activity avty = (Activity)(dataKey.context());
        if((usrId != null) && (usrId.isEmpty() == false))
            ((EditText)(avty.findViewById(R.id.usrIdHldr))).setText(usrId);
        if((phone != null) && (phone.isEmpty() == false))
            ((EditText)(avty.findViewById(R.id.phNumHldr))).setText(phone);
        if((ccard != null) && (ccard.isEmpty() == false))
            ((EditText)(avty.findViewById(R.id.crCardHldr))).setText(ccard);
        if((bnkac != null) && (bnkac.isEmpty() == false))
            ((EditText)(avty.findViewById(R.id.bnkAcHldr))).setText(bnkac);
        if((rcInvl != null) && (rcInvl.isEmpty() == false))
            ((EditText)(avty.findViewById(R.id.rcdIntvlHldr))).setText(rcInvl);
    }
}
