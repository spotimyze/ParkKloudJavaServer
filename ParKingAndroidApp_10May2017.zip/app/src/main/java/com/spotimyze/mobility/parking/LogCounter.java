package com.spotimyze.mobility.parking;

import java.util.Comparator;

/**
 * Created by S.Rajesh Kumar on 4/10/2017.
 */
public class LogCounter {
    private int                 count = 0;
    public  LogCounter()        {count = 0;}

    public  void count(int val) {count = val;}
    public  int  count()        {return(count);}
}
