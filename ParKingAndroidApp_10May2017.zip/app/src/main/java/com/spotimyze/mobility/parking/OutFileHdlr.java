package com.spotimyze.mobility.parking;

import android.content.Context;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by S.Rajesh Kumar on 3/15/2017.
 */
public class OutFileHdlr {
    private String         fnm;
    private FileWriter fwr;
    private BufferedWriter bwr;
    private File           fref;

    public OutFileHdlr() {fnm = null; fwr = null; bwr = null;}

    public boolean open(Context ctxt, String name, boolean append) {
        File outFile = new File(ctxt.getFilesDir(), name);
        if(outFile == null) return(false);
        try {fwr = new FileWriter(outFile, append); bwr = new BufferedWriter(fwr); fnm = name;}
        catch(IOException ioe) {fwr = null; bwr = null; fnm = null; return(false);}
        fref = outFile;
        return(true);
    }

    public void close() {
        try {if(fwr != null) fwr.close(); if(bwr != null) bwr.close();}
        catch(IOException ioe) {}
        fnm = null; fwr = null; bwr = null;
    }

    public boolean writeLine(String str) {
        if((str == null) || (bwr == null)) return(false);
        try {bwr.write(str); bwr.newLine(); bwr.flush(); return(true);}
        catch (IOException e) {return(false);}
    }

    public void flush() {try{if(bwr != null) bwr.flush();} catch(IOException e) {}}

    public boolean write(String str) {
        if((str == null) || (bwr == null)) return(false);
        try {bwr.write(str); return(true);} catch (IOException e) {return(false);}
    }

    public boolean write(StringBuilder wsb) {
        if((wsb == null) || (bwr == null)) return (false);
        try {bwr.append(wsb); return(true);} catch (IOException e) {return(false);}
    }

    public boolean writeLine(StringBuilder wsb) {
        if((wsb == null) || (bwr == null)) return (false);
        try {bwr.append(wsb); bwr.newLine(); return(true);} catch (IOException e) {return(false);}
    }

    public static void delete(Context ctxt, String nm) {
        if((nm == null) || (nm.isEmpty() == true)) return;
        File f = new File(ctxt.getFilesDir(), nm);
        if((f.exists() == true) && (f.isDirectory() == false)) f.delete();
    }
}
