package com.spotimyze.mobility.parking;

import android.widget.EditText;

import java.util.Calendar;

/**
 * Created by S.Rajesh Kumar on 4/18/2017.
 */
public class Util {
    public static int MAIN_VW         = 1;
    public static int HLP_VW          = 2;
    public static int PRF_VW          = 3;
    public static int BCNFLTR_VW      = 4;
    public static int MNGSPT_VW       = 5;
    public static int FNDPRK_VW       = 6;
    public static int BCNINFORGN_VW   = 7;
    public static int BCNINFOFLTR_VW  = 8;
    private static String[] months = {"Jan", "Feb", "Mar", "Apr",
        "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    public static String getDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        return(String.valueOf(calendar.get(Calendar.DAY_OF_MONTH)) + "-"
            + months[calendar.get(Calendar.MONTH)] + "-" + String.valueOf(calendar.get(Calendar.YEAR)));
    }

    public static String getTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        return(String.valueOf(calendar.get(Calendar.HOUR_OF_DAY)) + ":"
                + String.valueOf(calendar.get(Calendar.MINUTE)) + ":"
                + String.valueOf(calendar.get(Calendar.SECOND)) + ":"
                + String.valueOf(calendar.get(Calendar.MILLISECOND)));
    }

    public static String genLogFileName(String usrId) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        if((usrId == null) || (usrId.isEmpty() == true)) usrId = "";
        String nm = usrId + "_log_" + String.valueOf(calendar.get(Calendar.DAY_OF_MONTH))
                + months[calendar.get(Calendar.MONTH)] + String.valueOf(calendar.get(Calendar.YEAR))
                + "_" + String.valueOf(calendar.get(Calendar.HOUR_OF_DAY))
                + "_" + String.valueOf(calendar.get(Calendar.MINUTE))
                + "_" + String.valueOf(calendar.get(Calendar.SECOND))
                + ".csv";
        return(nm);
    }
}
