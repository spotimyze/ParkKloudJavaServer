package com.spotimyze.mobility.parking;

import com.google.android.gms.maps.model.Marker;

/**
 * Created by S.Rajesh Kumar on 4/20/2017.
 */
public class SpotInfo {
    private Marker mrkr;
    private String id;
    private double lat;
    private double lon;
    private String addr;
    private String label;
    private String beacon;
    private String imgFile;

    public SpotInfo() {
        mrkr = null; id = null; lat = 0; lon = 0; addr = null; label = null; beacon = null;imgFile = null;
    }

    public void   mrkr(Marker val)    {mrkr = val;}
    public void   id(String val)      {id = val;}
    public void   lat(double val)     {lat = val;}
    public void   lon(double val)     {lon = val;}
    public void   addr(String val)    {addr = val;}
    public void   label(String val)   {label = val;}
    public void   beacon(String val)  {beacon = val;}
    public void   imgFile(String val) {imgFile = val;}

    public Marker mrkr()              {return(mrkr);}
    public String id()                {return(id);}
    public double lat()               {return(lat);}
    public double lon()               {return(lon);}
    public String addr()              {return(addr);}
    public String label()             {return(label);}
    public String beacon()            {return(beacon);}
    public String imgFile()           {return(imgFile);}
}
