package com.spotimyze.mobility.parking;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Created by S.Rajesh Kumar on 4/18/2017.
 */
public class ImageDownloader {
    private Socket              sockToSrvr;
    private PrintWriter         strmToSrvr;
    private BufferedInputStream strmFromSrvr;
    private String              srvrAddr;
    private int                 port;
    private String              remoteFile;
    private Context             ctxt;
    private Bitmap              imgBmap;
    private View                parkSpotImgVwHldr;
    private View                mngAndFndVwHldr;
    private View                parkSpotImgVw;
    private String              locFile;

    public ImageDownloader(Context c) {
        srvrAddr          = KloudSrvr.srvrIp();
        port              = KloudSrvr.port();
        sockToSrvr        = null;
        strmFromSrvr      = null;
        strmToSrvr        = null;
        remoteFile        = null;
        ctxt              = c;
        imgBmap           = null;
        parkSpotImgVwHldr = null;
        mngAndFndVwHldr   = null;
        parkSpotImgVw     = null;
        locFile           = null;
    }

    public void downloadFile(String remf, View parkSpotImgVwHldrVal,
                 View mngAndFndVwHldrVal, View parkSpotImgVwVal) {
        remoteFile        = remf;
        parkSpotImgVwHldr = parkSpotImgVwHldrVal;
        mngAndFndVwHldr   = mngAndFndVwHldrVal;
        parkSpotImgVw     = parkSpotImgVwVal;
        locFile           = null;

        Thread dwnThrd = new Thread() {
            @Override
            public void run() {
                imgBmap = null;
                openServerConnection(); sendReq(); doDownload(); closeServerConnection();
                ((Activity)ctxt).runOnUiThread(new Runnable() {
                    public void run() {
                        ((Activity)ctxt).runOnUiThread(new Runnable() {
                            public void run() {
                                if(locFile == null) {
                                    Log.d("IMG-DWNL-LOG: ", "null locFile, cannot set image");
                                    return;
                                }
                                Bitmap bmp = BitmapFactory.decodeFile(locFile);
                                if(bmp == null) {Log.d("IMG-DWNL-LOG: ", "good - bitmap ok");}
                                else {Log.d("IMG-DWNL-LOG: ", "null bitmap");}
                                ((ImageView)parkSpotImgVw).setImageBitmap(bmp);
                                mngAndFndVwHldr.setVisibility(View.GONE);
                                parkSpotImgVwHldr.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                });
            }
        };

        dwnThrd.start();
    }

    private void sendReq() {
        if(strmToSrvr == null) return;
        String req = "GET /downloadFile " + remoteFile + " HTTP/1.1\r\n\r\n";
        strmToSrvr.write(req); strmToSrvr.flush();
    }

    private void doDownload() {
        boolean gotContLen = false;
        int     contLen    = 0;
        while(true) {
            String inLine = getLine(strmFromSrvr); if(inLine == null) break;
            if((gotContLen == true) &&
               (inLine.replace("\r", "").replace("\n", "").isEmpty() == true)) break;
            if(inLine.trim().startsWith("Content-Length:") == true) {
                // an empty line after this signifies start of content
                String s = inLine.replace("Content-Length:", "").trim();
                try {contLen = Integer.valueOf(s); gotContLen  = true; continue;}
                catch(NumberFormatException nfe) {contLen = 0;}
            }
        }
        if((gotContLen == false) || (contLen <= 0)) return;

        byte[]  imgByts  = new byte[contLen];
        int     totRdByts = 0, rdByts, chnk = 1024, avlByts;
        while(true) {
            try {
                avlByts = strmFromSrvr.available(); if(avlByts < 0) break;
                if(avlByts == 0) {try {Thread.sleep(1000);} catch(InterruptedException ie) {} continue;}
                rdByts = (avlByts < chnk) ? avlByts : chnk;
                rdByts  = strmFromSrvr.read(imgByts, totRdByts, rdByts); if(rdByts < 0) break;
                if(rdByts == 0) {try {Thread.sleep(1000);} catch(InterruptedException ie) {} continue;}
                totRdByts += rdByts;
                if(totRdByts >= contLen) break;
            } catch(IOException ioe) {return;}
        }
        if(totRdByts < contLen) {
            Log.d("IMG-DWNL-LOG: ", "error - bytes read " + totRdByts
                        + " less than content length " + contLen);
            return;
        }
        if(totRdByts <= 0) return;
        saveBytesToTmpFile(imgByts);
    }

    private void closeServerConnection() {
        if(sockToSrvr == null) return;
        if(strmFromSrvr != null) {
            try {strmFromSrvr.close();}
            catch(IOException e) {Log.d("IMG-DWNL-LOG: ", "Inp strm close exception");}
        }
        if(strmToSrvr != null) strmToSrvr.close();
        try {sockToSrvr.close();}
        catch(IOException e) {Log.d("IMG-DWNL-LOG: ", "Conn close exception");}
        strmFromSrvr = null; strmToSrvr   = null; sockToSrvr   = null;
    }

    private void openServerConnection() {
        try {sockToSrvr = new Socket(InetAddress.getByName(srvrAddr), port);}
        catch(UnknownHostException e) {
            Log.d("IMG-DWNL-LOG: ", "Unknown host exception"); sockToSrvr = null; return;
        } catch(IOException e) {
            Log.d("IMG-DWNL-LOG: ", "Server connect exception"); sockToSrvr = null; return;
        }

        try {
            strmFromSrvr = new BufferedInputStream(sockToSrvr.getInputStream());
            strmToSrvr = new PrintWriter(new BufferedWriter(new OutputStreamWriter
                                        (sockToSrvr.getOutputStream())), true);
        } catch(IOException e) {
            closeServerConnection();
            Log.d("IMG-DWNL-LOG: ", "Failed to open reader / writer. Closed the connection."); return;
        }
    }

    private String getLine(BufferedInputStream dis) {
        String outLine = "";
        while(true) {
            try {
                int c = dis.read(); if((c == -1) && (outLine.length() <= 0)) return(null);
                outLine += Character.toString((char)c);
                if(c == '\n') return(outLine);
            } catch(IOException e) {if(outLine.length() <= 0) return(null); return(outLine);}
        }
    }

    private void saveBytesToTmpFile(byte[] imgByts) {
        locFile = null;
        String extn = null;
        if(remoteFile.endsWith(".bmp")       == true) extn = ".bmp";
        else if(remoteFile.endsWith(".jpeg") == true) extn = ".jpeg";
        else if(remoteFile.endsWith(".jpg")  == true) extn = ".jpg";
        else if(remoteFile.endsWith(".png")  == true) extn = ".png";
        if(extn == null) {Log.d("IMG-DWNL-LOG: ", "no valid extn for image file"); return;}

        File file = new File(ctxt.getFilesDir(), "tmpParkSpotImg" + extn);
        FileOutputStream outStrm;
        try {outStrm = new FileOutputStream(file);}
        catch(FileNotFoundException fnfe) {
            Log.d("IMG-DWNL-LOG: ", "Failed to open file " + file.getAbsolutePath() + " for storing image");
            return;
        }
        try {outStrm.write(imgByts);}
        catch(IOException ie) {Log.d("IMG-DWNL-LOG: ", "error writing image to file"); return;}
        try {outStrm.close();} catch(IOException ie) {return;}
        locFile = file.getAbsolutePath();
        Log.d("IMG-DWNL-LOG: ", "wrote image into storage in file " + locFile);
    }

    public static int calculateInSampleSize(
        BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }
}
