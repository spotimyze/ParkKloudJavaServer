package com.spotimyze.mobility.parking;

import android.os.AsyncTask;

import java.util.LinkedList;
import java.util.Properties;
import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.activation.MailcapCommandMap;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 * Created by S.Rajesh Kumar on 3/29/2017.
 */
public class SndMail extends AsyncTask<Void,Void,Void> {
        private String             sndrId;
        private String             sndrPwd;
        private String             sndrUser;
        private String             sndrSrvr;
        private int                sndrPort;
        private boolean            sndrSecured;
        private String             subject;
        private String             message;
        private LinkedList<String> rcvrs;
        private LinkedList<String> files; // attachments filenames

        public SndMail(){
            sndrId       = null;
            sndrPwd      = null;
            sndrUser     = null;
            sndrSrvr     = null;
            sndrPort     = 25;
            sndrSecured  = false;
            subject      = null;
            message      = null;
            rcvrs        = new LinkedList<String>();
            files        = new LinkedList<String>();
        }

        public void               sndrId(String val)             {sndrId      = val;}
        public void               sndrPwd(String val)            {sndrPwd     = val;}
        public void               sndrUser(String val)           {sndrUser    = val;}
        public void               sndrSrvr(String val)           {sndrSrvr    = val;}
        public void               sndrPort(int val)              {sndrPort    = val;}
        public void               sndrSecured(boolean val)       {sndrSecured = val;}
        public void               subject(String val)            {subject     = val;}
        public void               message(String val)            {message     = val;}
        public void               rcvrs(LinkedList<String> val)  {rcvrs       = val;}
        public void               files(LinkedList<String> val)  {files       = val;}
        public void               addRcvr(String val)            {rcvrs.add(val);}
        public void               addFile(String val)            {files.add(val);}
        public void               delRcvr(String val)            {
            for(String r : rcvrs) {if(r.equalsIgnoreCase(val) == true) {rcvrs.remove(r); break;}}
        }
        public void               delFile(String val)            {
            for(String f : files) {if(f.equalsIgnoreCase(val) == true) {files.remove(f); break;}}
        }

        public String             sndrId()                       {return(sndrId);}
        public String             sndrPwd()                      {return(sndrPwd);}
        public String             sndrUser()                     {return(sndrUser);}
        public String             sndrSrvr()                     {return(sndrSrvr);}
        public int                sndrPort()                     {return(sndrPort);}
        public boolean            sndrSecured()                  {return(sndrSecured);}
        public String             subject()                      {return(subject);}
        public String             message()                      {return(message);}
        public LinkedList<String> rcvrs()                        {return(rcvrs);}
        public LinkedList<String> files()                        {return(files);}

        @Override protected void onPreExecute() {} //call - super.onPreExecute(); - first, then u'r code
        @Override protected void onPostExecute(Void aVoid) {} //super.onPostExecute(aVoid) first if using

        @Override
        protected Void doInBackground(Void... params) {
            Properties props = new Properties();
            //properties for gmail; for other mail-server, change these accordingly
            props.put("mail.smtp.host", sndrSrvr);
            props.put("mail.smtp.socketFactory.port", String.valueOf(sndrPort));
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", String.valueOf(sndrPort));

            //Creating a new session
            Session session = Session.getDefaultInstance(props,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(sndrId, sndrPwd); //authenticate password
                        }
                    });

            try {
                MimeMessage mm = new MimeMessage(session); //create MimeMessage object
                mm.setFrom(new InternetAddress(sndrId)); //set sender address
                for(String rcvr : rcvrs) {
                    mm.addRecipient(Message.RecipientType.TO, new InternetAddress(rcvr)); //add receiver
                }
                mm.setSubject(subject); //add subject
                mm.setText(message); //add message

                Multipart multipart = new MimeMultipart();
                BodyPart messageBodyPart = new MimeBodyPart(); messageBodyPart.setText(message);
                multipart.addBodyPart(messageBodyPart);

                for(String f : files) {
                    messageBodyPart = new MimeBodyPart();
                    messageBodyPart.setText(message);
                    multipart.addBodyPart(messageBodyPart);
                    messageBodyPart = new MimeBodyPart();
                    DataSource source = new FileDataSource(f);
                    messageBodyPart.setDataHandler(new DataHandler(source));
                    messageBodyPart.setFileName(f);
                    multipart.addBodyPart(messageBodyPart);
                }

                mm.setContent(multipart);
                //Transport.send(mm); //Sending email
                Transport transport = session.getTransport("smtp");
                transport.connect(sndrSrvr, sndrId, sndrPwd);
                transport.sendMessage(mm, mm.getAllRecipients());
                transport.close();
            } catch (MessagingException e) {e.printStackTrace();}

            return(null);
        }
}
