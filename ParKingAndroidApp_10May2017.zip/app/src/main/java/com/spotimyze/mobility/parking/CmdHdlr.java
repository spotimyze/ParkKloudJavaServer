package com.spotimyze.mobility.parking;

import android.app.Activity;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;

/**
 * Created by S.Rajesh Kumar on 3/15/2017.
 */
public class CmdHdlr {
    public void registerSpot(DataKey dataKey, String addr, String label) {
        if((dataKey.curLat() == null) || (dataKey.curLat().isEmpty() == true)) return;
        if((dataKey.curLon() == null) || (dataKey.curLon().isEmpty() == true)) return;
        String cmdArgs = " -lat \"" + dataKey.curLat() + "\" -lon \"" + dataKey.curLon() + "\"";
        if((label != null) && (label.isEmpty() == false)) cmdArgs += " -label \"" + label + "\"";

        String bcnId = "";
        Beacon bcn = dataKey.regnBeacon();
        if(bcn != null) {
            String uuid = bcn.uuid();
            String mjNm = String.valueOf(bcn.majNum()), mnNm = String.valueOf(bcn.minNum());
            if((uuid != null) && (uuid.isEmpty() == false))
                cmdArgs += " -beacon \"" + uuid + ":" + mjNm + ":" + mnNm + "\"";
        }

        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudRegisterSpot"); cmdRsp.cmdArgs(cmdArgs); cmdRsp.dataKey(dataKey);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }

    public void withdrawSpot(DataKey dataKey) {
        String cmdArgs = ""; if(dataKey.curMrkr() == null) return;
        String spotId = (String)(dataKey.curMrkr().getTag()); if(spotId == null) return;
        if(spotId.isEmpty() == true) return;
        if((dataKey.curLat() == null) || (dataKey.curLat().isEmpty() == true)) return;
        if((dataKey.curLon() == null) || (dataKey.curLon().isEmpty() == true)) return;
        cmdArgs += " -id \"" + spotId + "\"";
        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudWithdrawSpot"); cmdRsp.cmdArgs(cmdArgs); cmdRsp.dataKey(dataKey);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }

    public void occupySpot(DataKey dataKey, String label) {
        SpotInfo spInf = dataKey.parkDst(); if(spInf == null) return;
        Marker m       = spInf.mrkr();      if(m == null)     return;
        String id = (String)(m.getTag()); if((id == null) || (id.isEmpty() == true)) return;
        String cmdArgs = " -id \"" + id + "\"" + " -label \"" + label + "\"";
        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudOccupySpot"); cmdRsp.cmdArgs(cmdArgs); cmdRsp.dataKey(dataKey);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }

    public void releaseSpot(DataKey dataKey) {
        String s = readOccupiedSpot(dataKey); if((s == null) || (s.isEmpty() == true)) return;
        String parts[] = s.split(",", 2); if(parts.length < 2) return;
        String id = parts[0], lbl = parts[1]; if((id == null) || (id.isEmpty() == true)) return;
        if(lbl == null) lbl = "";
        String cmdArgs = " -id \"" + id + "\"" + " -label \"" + lbl + "\"";
        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudReleaseSpot"); cmdRsp.cmdArgs(cmdArgs); cmdRsp.dataKey(dataKey);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }

    public void findSpots(DataKey dataKey, String rs) {
        if((dataKey.curLat() == null) || (dataKey.curLat().isEmpty() == true)) return;
        if((dataKey.curLon() == null) || (dataKey.curLon().isEmpty() == true)) return;
        dataKey.clrParkSpots();
        if((rs != null) && (rs.isEmpty() == false)) {
            try {double rng = Double.valueOf(rs);}
            catch(NumberFormatException nfe) {rs = "1.0";}
        }
        String cmdArgs = " -lat \"" + dataKey.curLat() + "\" -lon \""
                + dataKey.curLon() + "\"" + " -range \"" + rs + "\"";
        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudFindSpots"); cmdRsp.cmdArgs(cmdArgs); cmdRsp.dataKey(dataKey);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }

    public void getRegisteredSpots(DataKey dataKey) {
        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudGetRegisteredSpots"); cmdRsp.cmdArgs(""); cmdRsp.dataKey(dataKey);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }

    private String readOccupiedSpot(DataKey dataKey) {
        String fl = dataKey.ocpdSpotFile();
        if((fl == null) || (fl.isEmpty() == true)) {
            Log.d("LOG: ", "no occupiedSpots file, unable to save last occupied spot");
            return(null);
        }
        InFileHdlr ifh = new InFileHdlr();
        if(ifh.open(dataKey.context(), fl) == false) {
            Log.d("LOG: ", "unable to open occupied spots file to read last occupied spot");
            return(null);
        }
        String s = null;
        while(true) {
            String inLine = ifh.getNextLine(); if(inLine == null) break;
            if(inLine.isEmpty() == true) continue; s = inLine; break;
        }
        if(s != null) Log.d("LOG: ", "successfully read last occupied spot");
        else Log.d("LOG: ", "no last occupied spot saved in file");
        ifh.close();
        return(s);
    }

    public void writeLogToSrvr(DataKey dataKey, String file, String logLine, LogCounter logCounter) {
        String cmdArgs = " -file \"" + file + "\" -logLine \"" + logLine + "\"";
        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudLogToFile"); cmdRsp.cmdArgs(cmdArgs); cmdRsp.dataKey(dataKey);
        cmdRsp.logCounter(logCounter);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }

    public void getImagesDir(DataKey dataKey) {
        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudGetImagesDir"); cmdRsp.cmdArgs(""); cmdRsp.dataKey(dataKey);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }

    public void addImageToSpot(DataKey dataKey, String spotId, String imgFile) {
        String cmdArgs = " -id \"" + spotId + "\" -imageFile \"" + imgFile + "\"";
        CmdRsp cmdRsp = new CmdRsp();
        cmdRsp.cmd("parkKloudAddImageToSpot"); cmdRsp.cmdArgs(cmdArgs); cmdRsp.dataKey(dataKey);
        (new ExecSrvrCmdTask()).execute(cmdRsp);
    }
}
