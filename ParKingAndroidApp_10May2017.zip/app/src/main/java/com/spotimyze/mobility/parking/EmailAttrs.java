package com.spotimyze.mobility.parking;

/**
 * Created by S.Rajesh Kumar on 3/29/2017.
 */
public class EmailAttrs {
    private String mailServer;
    private String mailFromAddress;
    private String mailUserName;
    private String mailPassword;
    private String mailSmtpPort;
    private String mailSocketType;

    public EmailAttrs(String v1, String v2, String v3,
                      String v4, String v5, String v6) {
        mailServer      = v1;
        mailFromAddress = v2;
        mailUserName    = v3;
        mailPassword    = v4;
        mailSmtpPort    = v5;
        mailSocketType  = v6;
    }

    public void init() {
        mailServer      = "smtp.mail.yahoo.com";
        mailFromAddress = "eyes.creative@yahoo.com";
        mailUserName    = "Creative Eyes";
        mailPassword    = "43CrtEys17";
        mailSmtpPort    = "25";
        mailSocketType  = "unsecured";
    }

    public void mailServer(String val)      {mailServer = val;};
    public void mailFromAddress(String val) {mailFromAddress = val;};
    public void mailUserName(String val)    {mailUserName = val;};
    public void mailPassword(String val)    {mailPassword = val;};
    public void mailSmtpPort(String val)    {mailSmtpPort = val;};
    public void mailSocketType(String val)  {mailSocketType = val;};

    public String mailServer()      {return(mailServer);};
    public String mailFromAddress() {return(mailFromAddress);};
    public String mailUserName()    {return(mailUserName);};
    public String mailPassword()    {return(mailPassword);};
    public String mailSmtpPort()    {return(mailSmtpPort);};
    public String mailSocketType()  {return(mailSocketType);};
}
