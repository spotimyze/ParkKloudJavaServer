package com.spotimyze.mobility.parking;

import android.graphics.Color;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.LinkedList;
import java.util.TreeSet;

/**
 * Created by S.Rajesh Kumar on 4/10/2017.
 */
public class BcnFltrHdlr {
    // 1st one holds checkboxes, next 8 hold uuid, last 2 hold major and minor number
    private static String hnt[] = {"", "****", "****", "****", "****", "****",
                                        "****", "****", "****", "***", "***"};
    private static int maxEms[] = {1, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3};
    private static int cols = 11; // 8 for UUID + 1 major number + 1 minor number + 1 for removal checkbox
    private static String wntdBcnsFile = "wntdBcns";

    public void drwBcnFltVw(DataKey dataKey, LinearLayout bcnNamesHldr,
                LinearLayout bcnInfoHldr, ScrollView bcnInfoCntnr) {
        readWantedBeacons(dataKey);
        TreeSet<Beacon> bcns = dataKey.wantedBeacons();
        for(Beacon bcn : bcns) {
            addNewBeaconFilterRow(dataKey, bcnNamesHldr, bcnInfoHldr, bcnInfoCntnr, bcn.name());
        }
        if((bcns == null) || (bcns.isEmpty() == true)) {
            addNewBeaconFilterRow(dataKey, bcnNamesHldr, bcnInfoHldr, bcnInfoCntnr, null);
        }
    }

    public void addNewBeaconFilterRow(DataKey dataKey, LinearLayout bcnNamesHldr,
        LinearLayout bcnInfoHldr, final ScrollView bcnInfoCntnr, String name) {
        LinearLayout ll = new LinearLayout(dataKey.context());
        ll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        ll.setOrientation(LinearLayout.HORIZONTAL);
        bcnNamesHldr.addView(ll);

        LinearLayout.LayoutParams prms = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        prms.setMargins(20, 0, 0, 0);
        CheckBox cb = new CheckBox(dataKey.context()); cb.setLayoutParams(prms); ll.addView(cb);

        EditText et = new EditText(dataKey.context()); et.setLayoutParams(prms); ll.addView(et);
        et.setMaxEms(8); et.setMinEms(8); et.setTextColor(Color.BLACK); et.setHint("abcdefgh");
        et.setText(((name == null) || (name.isEmpty() == true)) ? "" : name);

        TextView tv = new TextView(dataKey.context()); tv.setLayoutParams(prms); ll.addView(tv);
        tv.setText("..."); tv.setTextColor(Color.BLACK); tv.setTag(et);
        final LinearLayout nmsh =  bcnNamesHldr, infh = bcnInfoHldr;
        final DataKey dk = dataKey;
        {tv.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View arg0) {
                EditText et = (EditText)(arg0.getTag()); if(et == null) return;
                String name = et.getText().toString(); dk.edtBcnName(name);
                if((name == null) || (name.isEmpty() == true)) return;
                showBeaconInfoVw(dk, name, nmsh, infh, bcnInfoCntnr);
            }
        });}
    }

    public void removeBeaconFilterRows(DataKey dataKey, LinearLayout bcnNamesHldr) {
        int rowNum = 1;
        while(true) {
            int chs = bcnNamesHldr.getChildCount(); if(chs <= 2) break;
            if(rowNum >= chs) break;
            LinearLayout ll = (LinearLayout)(bcnNamesHldr.getChildAt(rowNum)); if(ll == null) break;
            CheckBox cb = (CheckBox)(ll.getChildAt(0));
            if(cb.isChecked() == false) {rowNum++; continue;}
            bcnNamesHldr.removeView(ll);
            Beacon bcn = findBcnEntry(dataKey, ((EditText)(ll.getChildAt(1))).getText().toString());
            if(bcn != null) {dataKey.wantedBeacons().remove(bcn); dataKey.removeWantedBeacon(bcn);}
        }
    }

    public void showBeaconInfoVw(DataKey dataKey, String name, LinearLayout bcnNamesHldr,
                                    LinearLayout bcnInfoHldr, ScrollView bcnInfoCntnr) {
        bcnNamesHldr.setVisibility(View.GONE); bcnInfoCntnr.setVisibility(View.VISIBLE);
        bcnInfoCntnr.setTag("beaconForFilter"); fillBcnInfo(dataKey, name, bcnInfoHldr);
        BcnSlctnPopulator bsp = new BcnSlctnPopulator(dataKey, bcnInfoHldr);
        bsp.populateNearbyBeaconsList();
        dataKey.curView(Util.BCNINFOFLTR_VW);
    }

    public void hideBeaconInfoVw(LinearLayout bcnNamesHldr, LinearLayout bcnInfoHldr,
                                         DataKey dataKey, ScrollView bcnInfoCntnr) {
        updateWantedBeacons(bcnInfoHldr, dataKey);
        bcnInfoCntnr.setVisibility(View.GONE); bcnNamesHldr.setVisibility(View.VISIBLE);
    }

    private void fillBcnInfo(DataKey dataKey, String name, LinearLayout bcnInfoHldr) {
        Beacon bcn = findBcnEntry(dataKey, name);
        for(int c1 = 0, cs1 = bcnInfoHldr.getChildCount(); c1 < cs1; c1++) {
            View vw = bcnInfoHldr.getChildAt(c1);
            if(vw.getId() == R.id.bcnNameHldr) {((TextView)vw).setText(name);}
            else if(vw.getId() == R.id.majNumHldr) {
                ((EditText)vw).setText((bcn == null) ? "" : String.valueOf(bcn.majNum()));
                BeaconMajMinNumCharChkr numChrChkr = new BeaconMajMinNumCharChkr((EditText)vw);
                ((EditText)vw).addTextChangedListener(numChrChkr);
                ((EditText)vw).setTag(numChrChkr);
            }
            else if(vw.getId() == R.id.minNumHldr) {
                ((EditText)vw).setText((bcn == null) ? "" : String.valueOf(bcn.minNum()));
                BeaconMajMinNumCharChkr numChrChkr = new BeaconMajMinNumCharChkr((EditText)vw);
                ((EditText)vw).addTextChangedListener(numChrChkr);
                ((EditText)vw).setTag(numChrChkr);
            }
            else if(vw.getId() == R.id.uuidHldr) {
                LinearLayout ll = (LinearLayout)vw;
                for(int c2 = 0, cs2 = ll.getChildCount(); c2 < cs2; c2++) {
                    View v2 = ll.getChildAt(c2);
                    int id = v2.getId();
                    String s = null;
                    if(id == R.id.uuidHldr1)      s = (bcn == null) ? "" : bcn.uuid().substring(0, 4);
                    else if(id == R.id.uuidHldr2) s = (bcn == null) ? "" : bcn.uuid().substring(4, 8);
                    else if(id == R.id.uuidHldr3) s = (bcn == null) ? "" : bcn.uuid().substring(8, 12);
                    else if(id == R.id.uuidHldr4) s = (bcn == null) ? "" : bcn.uuid().substring(12, 16);
                    else if(id == R.id.uuidHldr5) s = (bcn == null) ? "" : bcn.uuid().substring(16, 20);
                    else if(id == R.id.uuidHldr6) s = (bcn == null) ? "" : bcn.uuid().substring(20, 24);
                    else if(id == R.id.uuidHldr7) s = (bcn == null) ? "" : bcn.uuid().substring(24, 28);
                    else if(id == R.id.uuidHldr8) s = (bcn == null) ? "" : bcn.uuid().substring(28, 32);
                    if(s != null) {
                        ((EditText) v2).setText(s);
                        BeaconUuidCharChkr      uuidchrChkr = new BeaconUuidCharChkr((EditText) v2);
                        ((EditText) v2).addTextChangedListener(uuidchrChkr);
                        ((EditText) v2).setTag(uuidchrChkr);
                    }
                }
            }
        }
    }

    public void updateWantedBeacons(LinearLayout bcnInfoHldr, DataKey dataKey) {
        Beacon edtBcn = readBeaconInfoFrmVw(bcnInfoHldr); if(edtBcn == null) return;
        Beacon bcn = findBcnEntry(dataKey, edtBcn.name());
        if(bcn == null) {bcn = edtBcn; dataKey.addWantedBeacon(edtBcn);}
        else {bcn.uuid(edtBcn.uuid()); bcn.majNum(edtBcn.majNum()); bcn.minNum(edtBcn.minNum());}
    }

    public Beacon readBeaconInfoFrmVw(LinearLayout bcnInfoHldr) {
        String name = null, uuid = "", mjNm = null, mnNm = null;
        for(int c = 0, n = bcnInfoHldr.getChildCount(); c < n; c++) {
            View vw = bcnInfoHldr.getChildAt(c); if(vw == null) continue;
            int  id = vw.getId();
            if(id == (R.id.bcnNameHldr)) {name = ((TextView)(vw)).getText().toString();}
            else if(id == (R.id.majNumHldr)) {
                mjNm = ((EditText)(vw)).getText().toString();
                ((EditText)vw).removeTextChangedListener((TextWatcher)(vw.getTag()));
            }
            else if(id == (R.id.minNumHldr)) {
                mnNm = ((EditText)(vw)).getText().toString();
                ((EditText)vw).removeTextChangedListener((TextWatcher)(vw.getTag()));
            }
            else if(id == (R.id.uuidHldr)) {
                LinearLayout ll = (LinearLayout)vw;
                for(int c2 = 0, cs2 = ll.getChildCount(); c2 < cs2; c2++) {
                    View v2 = ll.getChildAt(c2);
                    id = v2.getId();
                    if((id == R.id.uuidHldr1) || (id == R.id.uuidHldr2) || (id == R.id.uuidHldr3) ||
                            (id == R.id.uuidHldr4) || (id == R.id.uuidHldr5) || (id == R.id.uuidHldr6) ||
                            (id == R.id.uuidHldr7) || (id == R.id.uuidHldr8)) {
                        String s = ((EditText)v2).getText().toString(); if(s == null) s = "    ";
                        while(s.length() < 4) {s = "0" + s;} uuid += s;
                        ((EditText)v2).removeTextChangedListener((TextWatcher)(v2.getTag()));
                    }
                }
            }
        }
        if((name == null) || (name.isEmpty() == true) || (uuid == null) || (uuid.isEmpty() == true) ||
           (mjNm == null) || (mjNm.isEmpty() == true) || (mnNm == null) || (mnNm.isEmpty() == true)) {
            return(null);
        }

        return(new Beacon(name, uuid, Integer.valueOf(mjNm), Integer.valueOf(mnNm)));
    }

    private Beacon findBcnEntry(DataKey dataKey, String name) {
        TreeSet<Beacon> bcns = dataKey.wantedBeacons();
        if((bcns == null) || (bcns.isEmpty() == true)) return(null);
        for(Beacon bcn : bcns) {if(bcn.name().equals(name) == true) return(bcn);}
        return(null);
    }

    public void saveWantedBeacons(DataKey dataKey) {
        OutFileHdlr ofh = new OutFileHdlr();
        if(ofh.open(dataKey.context(), wntdBcnsFile, false) == false) {
            Log.d("LOG:", "unable to open wntdBcns file to write");
            return;
        }
        TreeSet<Beacon> bcns = dataKey.wantedBeacons();
        if((bcns != null) && (bcns.isEmpty() == false)) {
            for (Beacon bcn : bcns) {
                ofh.writeLine(bcn.name() + ":" + bcn.uuid() + ":" + bcn.majNum() + ":" + bcn.minNum());
            }
        }
        ofh.close();
    }

    private void readWantedBeacons(DataKey dataKey) {
        InFileHdlr ifh = new InFileHdlr();
        if(ifh.open(dataKey.context(), wntdBcnsFile) == false) {
            Log.d("LOG:", "unable to open wntdBcns file to read");
            return;
        }
        dataKey.wantedBeacons().clear();
        while(true) {
            String inLine = ifh.getNextLine(); if(inLine == null) break;
            if(inLine.isEmpty() == true) continue;
            String parts[] = inLine.split(":"); if(parts.length < 4) continue;
            try {
                int mj = Integer.valueOf(parts[2]), mn = Integer.valueOf(parts[3]);
                Beacon bcn = new Beacon(parts[0], parts[1], mj, mn);
                dataKey.addWantedBeacon(bcn);
            } catch(NumberFormatException nfe) {}
        }
        ifh.close();
    }
}
