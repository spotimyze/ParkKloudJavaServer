package com.spotimyze.mobility.parking;

/**
 * Created by S.Rajesh Kumar on 4/14/2017.
 */
public class CmdRsp {
    private String     cmd;
    private String     cmdArgs;
    private String     srvrRsp;
    private DataKey    dataKey;
    private LogCounter logCounter;

    public CmdRsp() {cmd = ""; cmdArgs = ""; srvrRsp = ""; dataKey = null; logCounter = null;}

    public String     cmd()                  {return(cmd);}
    public String     cmdArgs()              {return(cmdArgs);}
    public String     srvrRsp()              {return(srvrRsp);}
    public DataKey    dataKey()              {return(dataKey);}
    public LogCounter logCounter()           {return(logCounter);}

    public void    cmd(String val)            {cmd     = val;}
    public void    cmdArgs(String val)        {cmdArgs = val;}
    public void    srvrRsp(String val)        {srvrRsp = val;}
    public void    dataKey(DataKey val)       {dataKey = val;}
    public void    logCounter(LogCounter val) {logCounter = val;}
}
