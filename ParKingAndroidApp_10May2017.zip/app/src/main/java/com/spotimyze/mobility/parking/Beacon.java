package com.spotimyze.mobility.parking;

import java.util.Comparator;

/**
 * Created by S.Rajesh Kumar on 4/10/2017.
 */
public class Beacon {
    private String name;
    private String uuid;
    private int    majNum;
    private int    minNum;
    private int    txRssi;
    private int    rxRssi;
    private String hwAddr;

    public Beacon(String nm) {name = nm;}
    public Beacon(String v1, int v2, int v3) {uuid = v1; majNum = v2; minNum = v3;}
    public Beacon(String v1, String v2, int v3, int v4) {
        name = v1; uuid = v2; majNum = v3; minNum = v4; hwAddr = "";
    }

    public void name(String val)   {name = val;}
    public void uuid(String val)   {uuid = val;}
    public void majNum(int val)    {majNum = val;}
    public void minNum(int val)    {minNum = val;}
    public void txRssi(int val)    {txRssi = val;}
    public void rxRssi(int val)    {rxRssi = val;}
    public void hwAddr(String val) {hwAddr = val;}

    public String name()           {return(name);}
    public String uuid()           {return(uuid);}
    public int    majNum()         {return(majNum);}
    public int    minNum()         {return(minNum);}
    public int    txRssi()         {return(txRssi);}
    public int    rxRssi()         {return(rxRssi);}
    public String hwAddr()         {return(hwAddr);}

    public boolean isSame(Beacon b2) {
        if(b2.uuid().equalsIgnoreCase(uuid()) == false) return(false);
        if(b2.majNum() != majNum()) return(false);
        if(b2.minNum() != minNum()) return(false);
        if(b2.hwAddr().equalsIgnoreCase(hwAddr()) == false) return(false);
        return(true);
    }

    public static class BeaconComparator implements Comparator<Beacon> {
        public int compare (Beacon b1, Beacon b2) {
            int res = b1.uuid().compareToIgnoreCase(b2.uuid()); if(res != 0) return(res);
            if(b1.majNum() > b2.majNum()) return(1); if(b1.majNum() < b2.majNum()) return(-1);
            if(b1.minNum() > b2.minNum()) return(1); if(b1.minNum() < b2.minNum()) return(-1);
            return(b1.hwAddr().compareToIgnoreCase(b2.hwAddr()));
        }
    }
}
