package com.spotimyze.mobility.parking;

import android.graphics.Color;
import android.provider.ContactsContract;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.TreeSet;

/**
 * Created by S.Rajesh Kumar on 4/10/2017.
 */
public class LastLocnHdlr {
    public void saveLastLocation(DataKey dataKey) {
        String fl = dataKey.lastLocnFile();
        if((fl == null) || (fl.isEmpty() == true)) {
            Log.d("LOG: ", "no last location file, unable to save location");
            return;
        }
        OutFileHdlr ofh = new OutFileHdlr();
        if(ofh.open(dataKey.context(), fl, false) == false) {
            Log.d("LOG: ", "unable to open last location file to save location");
            return;
        }
        ofh.writeLine((dataKey.curLat() + "," + dataKey.curLon()));
        Log.d("LOG: ", "successfully saved location");
        ofh.close();
    }

    public void restoreSavedLocation(DataKey dataKey) {
        String fl = dataKey.lastLocnFile();
        if((fl == null) || (fl.isEmpty() == true)) {
            Log.d("LOG: ", "no last location file, no saved location to go to");
            return;
        }
        InFileHdlr ifh = new InFileHdlr();
        if(ifh.open(dataKey.context(), fl) == false) {
            Log.d("LOG: ", "unable to open last location file, no saved location to go to");
            return;
        }
        while (true) {
            String inLine = ifh.getNextLine(); if(inLine == null) break;
            if(inLine.isEmpty() == true) continue;
            String[] flds = inLine.split(","); if(flds.length < 2) continue;
            dataKey.curLat(flds[0]); dataKey.curLon(flds[1]);
            Log.d("LOG: ", "successfully read saved location");
            break;
        }
        ifh.close();
    }
}
