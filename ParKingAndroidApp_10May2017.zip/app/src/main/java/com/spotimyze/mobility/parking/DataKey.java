package com.spotimyze.mobility.parking;

import android.content.Context;
import android.util.Log;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.Marker;

import java.util.LinkedList;
import java.util.TreeSet;

/**
 * Created by S.Rajesh Kumar on 4/17/2017.
 */
public class DataKey {
    private Context              ctxt;
    private String               lastLocnFile;
    private String               curLat;
    private String               curLon;
    private Marker               curMrkr;
    private boolean              manageMode; // true - manage, false - find parking; default = false
    private BitmapDescriptor     newMrkrBmd;
    private BitmapDescriptor     rgdMrkrBmd;
    private GoogleMap            appMap;
    private LinkedList<Marker>   regdSpots;
    private LinkedList<SpotInfo> parkSpots;
    private int                  scrnWidth;
    private int                  scrnHeight;
    private String               ocpdSpotFile;
    private SpotInfo             parkDst;
    private String               ocpdSpotId;
    private String               ocpdSpotLbl;
    private String               prfFile;
    private String               addr;
    private String               label;
    private String               imgFile;
    private String               imgsDir;
    private String               usrId;
    private String               phNum;
    private TreeSet<Beacon>      wantedBeacons;
    private Beacon               regnBeacon;
    private int                  curView;
    private String               edtBcnName;

    public DataKey() {init();}

    public void   context(Context val)              {ctxt          = val;}
    public void   lastLocnFile(String val)          {lastLocnFile  = val;}
    public void   curLat(String val)                {curLat        = val;}
    public void   curLon(String val)                {curLon        = val;}
    public void   curMrkr(Marker val)               {curMrkr       = val;}
    public void   manageMode(boolean val)           {manageMode    = val;}
    public void   newMrkrBmd(BitmapDescriptor val)  {newMrkrBmd    = val;}
    public void   rgdMrkrBmd(BitmapDescriptor val)  {rgdMrkrBmd    = val;}
    public void   appMap(GoogleMap val)             {appMap        = val;}
    public void   scrnWidth(int val)                {scrnWidth     = val;}
    public void   scrnHeight(int val)               {scrnHeight    = val;}
    public void   ocpdSpotFile(String val)          {ocpdSpotFile  = val;}
    public void   parkDst(SpotInfo val)             {parkDst       = val;}
    public void   prfFile(String val)               {prfFile       = val;}
    public void   addr(String val)                  {addr          = val;}
    public void   label(String val)                 {label         = val;}
    public void   imgFile(String val)               {imgFile       = val;}
    public void   imgsDir(String val)               {imgsDir       = val;}
    public void   usrId(String val)                 {usrId         = val;}
    public void   phNum(String val)                 {phNum         = val;}
    public void   wantedBeacons(TreeSet<Beacon> vl) {wantedBeacons = vl;}
    public void   regnBeacon(Beacon val)            {regnBeacon    = val;}
    public void   curView(int val)                  {curView       = val;}
    public void   edtBcnName(String val)            {edtBcnName    = val;}

    public Context            context()             {return(ctxt);}
    public String             lastLocnFile()        {return(lastLocnFile);}
    public String             curLat()              {return(curLat);}
    public String             curLon()              {return(curLon);}
    public Marker             curMrkr()             {return(curMrkr);}
    public boolean            manageMode()          {return(manageMode);}
    public BitmapDescriptor   newMrkrBmd()          {return(newMrkrBmd);}
    public BitmapDescriptor   rgdMrkrBmd()          {return(rgdMrkrBmd);}
    public GoogleMap          appMap()              {return(appMap);}
    public int                scrnWidth()           {return(scrnWidth);}
    public int                scrnHeight()          {return(scrnHeight);}
    public String             ocpdSpotFile()        {return(ocpdSpotFile);}
    public SpotInfo           parkDst()             {return(parkDst);}
    public String             prfFile()             {return(prfFile);}
    public String             addr()                {return(addr);}
    public String             label()               {return(label);}
    public String             imgFile()             {return(imgFile);}
    public String             imgsDir()             {return(imgsDir);}
    public String             usrId()               {return(usrId);}
    public String             phNum()               {return(phNum);}
    public TreeSet<Beacon>    wantedBeacons()       {return(wantedBeacons);}
    public Beacon             regnBeacon()          {return(regnBeacon);}
    public int                curView()             {return(curView);}
    public String             edtBcnName()          {return(edtBcnName);}

    public void addRegdSpot(Marker mrkr) {
        if(regdSpots == null) regdSpots = new LinkedList<Marker>();
        for(int i = 0, len = regdSpots.size(); i < len; i++) {if(regdSpots.get(i) == mrkr) {return;}}
        regdSpots.add(mrkr);
    }

    public void delRegdSpot(Marker mrkr) {
        if((regdSpots == null) || (regdSpots.isEmpty() == true)) return;
        for(int i = 0, len = regdSpots.size(); i < len; i++) {
            if(regdSpots.get(i) == mrkr) {regdSpots.remove(i); return;}
        }
    }

    public void clrRegdSpots() {for(Marker m : regdSpots) {m.remove();} regdSpots.clear();}

    public void addParkSpot(SpotInfo spInf) {
        if(parkSpots == null) parkSpots = new LinkedList<SpotInfo>();
        for(int i = 0, len = parkSpots.size(); i < len; i++) {
            if(parkSpots.get(i).id().equals(spInf.id()) == true) {return;}
        }
        parkSpots.add(spInf);
    }

    public void addParkSpot(Marker mrkr, String spId, double lat, double lon,
                String addr, String label, String beacon, String imgFile) {
        if(parkSpots == null) parkSpots = new LinkedList<SpotInfo>();
        for(int i = 0, len = parkSpots.size(); i < len; i++) {
            if(parkSpots.get(i).id().equals(spId) == true) {return;}
        }
        SpotInfo spInf = new SpotInfo();
        spInf.mrkr(mrkr);   spInf.id(spId); spInf.lat(lat); spInf.lon(lon); spInf.addr(addr);
        spInf.label(label); spInf.beacon(beacon); spInf.imgFile(imgFile);
        parkSpots.add(spInf);
    }

    public SpotInfo findParkSpot(Marker m) {
        String tag = m.getTag().toString(); if(tag == null) return(null);
        return(findParkSpot(tag));
    }

    public SpotInfo findParkSpot(String spotId) {
        if((parkSpots == null) || (parkSpots.isEmpty() == true)) return(null);
        for(SpotInfo spInf : parkSpots) {if(spInf.id().equals(spotId) == true) {return(spInf);}}
        return(null);
    }

    public Marker findParkMrkr(String spotId) {
        if((parkSpots == null) || (parkSpots.isEmpty() == true)) return(null);
        for(SpotInfo spInf : parkSpots) {if(spInf.id().equals(spotId) == true) {return(spInf.mrkr());}}
        return(null);
    }

    public void clrParkSpots() {
        for(SpotInfo spInf : parkSpots) {spInf.mrkr().remove();} parkSpots.clear();
    }
    public void clearWantedBeacons() {wantedBeacons.clear();}
    public void addWantedBeacon(Beacon bcn) {
        if(wantedBeacons.contains(bcn) == false) wantedBeacons.add(bcn);
    }
    public void removeWantedBeacon(Beacon bcn) {
        Beacon b2 = wantedBeacons.ceiling(bcn); if(b2.isSame(bcn) == true) wantedBeacons.remove(b2);
    }

    public void init() {
        ctxt          = null;
        lastLocnFile  = null;
        curLat        = null;
        curLon        = null;
        curMrkr       = null;
        manageMode    = false;
        newMrkrBmd    = null;
        rgdMrkrBmd    = null;
        appMap        = null;
        regdSpots     = new LinkedList<Marker>();
        parkSpots     = new LinkedList<SpotInfo>();
        scrnWidth     = 0;
        scrnHeight    = 0;
        ocpdSpotFile  = null;
        parkDst       = null;
        prfFile       = null;
        addr          = null;
        label         = null;
        imgFile       = null;
        imgsDir       = null;
        usrId         = null;
        phNum         = null;
        wantedBeacons = new TreeSet<Beacon>(new Beacon.BeaconComparator());
        regnBeacon    = null;
        curView       = 0;
        edtBcnName    = "";
    }

    public void clear() {clrRegdSpots(); clrParkSpots(); clearWantedBeacons(); init();}
}
