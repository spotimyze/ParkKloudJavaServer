package com.spotimyze.mobility.parking;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Created by S.Rajesh Kumar on 3/15/2017.
 */
public class ExecSrvrCmdTask extends AsyncTask<CmdRsp, Integer, CmdRsp> {
    protected CmdRsp doInBackground(CmdRsp... cmdRsps) {
        if((cmdRsps == null) || (cmdRsps.length < 1)) return(null);
        CmdRsp cmdRsp   = cmdRsps[0];
        DataKey dataKey = cmdRsp.dataKey();
        String srvrAddr = KloudSrvr.srvrIp(), portStr = KloudSrvr.portStr();
        if((srvrAddr == null) || (srvrAddr.isEmpty() == true)) return(null);
        if((portStr == null)  || (portStr.isEmpty()  == true)) return(null);
        try {int port = Integer.valueOf(portStr); KloudSrvr.port(port);}
        catch(NumberFormatException nfe) {return(null);}
        String rspFrmSrvr = sendCmdToServer(cmdRsp);
        cmdRsp.srvrRsp(rspFrmSrvr);
        return(cmdRsp);
    }

    protected void onProgressUpdate(Integer... progress) {}
    protected void onPostExecute(CmdRsp cmdRsp) {(new RspHdlr()).prcsSrvrRsp(cmdRsp);}

    public Socket openServerConnection(String serverAddr, int serverPort) {
        Socket sockToSrvr;
        try {
            if(serverAddr == null) sockToSrvr = new Socket("", serverPort);
            else sockToSrvr = new Socket(InetAddress.getByName(serverAddr), serverPort);
            Log.d("LOG: ", "Connected to server"); return(sockToSrvr);
        } catch(UnknownHostException uhe) {
            Log.d("LOG: ", "Unknown host. Cannot make connection."); return(null);
        } catch(IOException ioe) {
            Log.d("LOG: ", "Exception trying to connect to server."); return(null);
        }
    }

    public void closeServerConnection(Socket sock, PrintWriter outStrm, BufferedReader inStrm) {
        if(inStrm != null) {
            try {inStrm.close();}
            catch(IOException e) {Log.d("LOG: ", "Exception closing server input stream");}
        }
        if(outStrm != null) outStrm.close();
        if(sock != null) {
            try {sock.close();}
            catch(IOException e) {Log.d("LOG: ", "Exception closing socket to server.");}
        }
    }

    public String sendCmdToServer(CmdRsp cmdRsp) {
        DataKey dataKey = cmdRsp.dataKey();
        if((cmdRsp == null) || (cmdRsp.cmd() == null) || (cmdRsp.cmd().isEmpty() == true))
            return("");
        if(dataKey == null) return("");
        String cmdArgs = cmdRsp.cmdArgs(), usrCmd = cmdRsp.cmd();
        if(cmdArgs == null) cmdArgs = "";
        PrintWriter    strmToSrvr   = null;
        BufferedReader strmFromSrvr = null;
        Socket sockToSrvr = openServerConnection(KloudSrvr.srvrIp(), KloudSrvr.port());
        if(sockToSrvr == null) return("");
        try {
            strmFromSrvr = new BufferedReader(
                    new InputStreamReader(sockToSrvr.getInputStream()));
            strmToSrvr = new PrintWriter(new BufferedWriter
                    (new OutputStreamWriter(sockToSrvr.getOutputStream())), true);
        } catch(IOException e) {
            closeServerConnection(sockToSrvr, strmToSrvr, strmFromSrvr);
            Log.d("LOG: ", "Failed to open reader / writer. Closed the connection.");
            return("");
        }

        String httpPostStr = "POST /" + usrCmd + " HTTP/1.1\r\n"
                + "Content-Length: " + String.valueOf((cmdArgs.length()) + "\r\n".length())
                + "\r\n\r\n" + cmdArgs + "\r\n";
        strmToSrvr.write(httpPostStr);
        strmToSrvr.flush();

        String rspFrmSrvr = "";
        while(true) {
            try {
                String inLine = strmFromSrvr.readLine();
                if(inLine == null) break;
                if(inLine.startsWith("HTTP/1.1 200 OK") == true) continue;
                if(inLine.startsWith("Content-Type: text/plain") == true) continue;
                if(inLine.startsWith("Content-Length:") == true) continue;
                rspFrmSrvr += inLine + "\r\n";
            }
            catch(IOException e) {Log.d("LOG: ", "Exception reading server response"); break;}
        }
        closeServerConnection(sockToSrvr, strmToSrvr, strmFromSrvr);
        if(rspFrmSrvr == null) return("");
        return(rspFrmSrvr);
    }
}
