package com.spotimyze.mobility.parking;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;

/**
 * Created by S.Rajesh Kumar on 4/12/2017.
 */
public class BeaconUuidCharChkr implements TextWatcher {
    private EditText et = null;
    public BeaconUuidCharChkr(EditText srcEt) {et = srcEt;}
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
    public void onTextChanged(CharSequence s, int start, int before, int count) {}
    public void afterTextChanged(Editable edtbl) {
        if(et == null) return;
        String s1     = et.getText().toString();
        if((s1 == null) || (s1.isEmpty() == true)) return;
        String s2     = "";
        boolean modfd = false;
        for(int p = 0, len = s1.length(); p < len; p++) {
            if(p >= 4) {modfd = true; break;}
            char c = s1.charAt(p);
            if(Character.isDigit(c) == true)  {s2 += Character.toString(c);}
            else if((c >= 'A') && (c <= 'F')) {s2 += Character.toString(c);}
            else if((c >= 'a') && (c <= 'f')) {
                c -= ('a' - 'A'); s2 += Character.toString(c); modfd = true;
            }
            else modfd = true;
        }
        if(modfd == true) et.setText(s2);
    }
}
