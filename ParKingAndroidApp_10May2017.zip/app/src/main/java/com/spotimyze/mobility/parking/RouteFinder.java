package com.spotimyze.mobility.parking;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by S.Rajesh Kumar on 4/13/2017.
 */
public class RouteFinder extends AsyncTask<String, Void, String> {
    private DataKey dataKey;
    public RouteFinder(DataKey dk) {dataKey = dk;}
    @Override
    protected String doInBackground(String... url) { // download data in non-ui thread
        String data = ""; // For storing data from web service
        try {data = getJsonDataFromUrl(url[0]);} // fetch data from web service
        catch(Exception e) {Log.d("Background Task",e.toString());}
        return data;
    }

    @Override
    protected void onPostExecute(String result) { // execute in UI thread, after doInBackground()
        super.onPostExecute(result);
        RouteDisplayer rtDsplr = new RouteDisplayer(dataKey);
        rtDsplr.execute(result); // Invokes the thread for parsing the JSON data
    }

    public String getJsonDataFromUrl(String strUrl) throws IOException {
        String            content = "";
        InputStream       isr     = null;
        HttpURLConnection conn    = null;
        try{
            URL url = new URL(strUrl);
            conn = (HttpURLConnection) url.openConnection(); // http connection to communicate with url
            conn.connect(); // Connecting to url
            isr = conn.getInputStream(); // Reading data from url
            BufferedReader br = new BufferedReader(new InputStreamReader(isr));
            StringBuffer sb = new StringBuffer();
            String line = "";
            while((line = br.readLine()) != null) {sb.append(line);}
            content = sb.toString();
            br.close();

        } catch(Exception e){Log.d("LOG: ", "Exception downloading url" + e.toString());}
        finally {isr.close(); conn.disconnect();}
        return(content);
    }
}
