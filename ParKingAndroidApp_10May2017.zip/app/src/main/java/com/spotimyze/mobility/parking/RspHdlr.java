package com.spotimyze.mobility.parking;

import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by S.Rajesh Kumar on 3/15/2017.
 */
public class RspHdlr {
    public void prcsSrvrRsp(CmdRsp cmdRsp) {
        if(cmdRsp.cmd().equalsIgnoreCase("parkKloudRegisterSpot") == true)
            prcsRegisterSpotRsp(cmdRsp);
        else if(cmdRsp.cmd().equalsIgnoreCase("parkKloudWithdrawSpot") == true)
            prcsWithdrawSpotRsp(cmdRsp);
        else if(cmdRsp.cmd().equalsIgnoreCase("parkKloudOccupySpot") == true)
            prcsOccupySpotRsp(cmdRsp);
        else if(cmdRsp.cmd().equalsIgnoreCase("parkKloudReleaseSpot") == true)
            prcsReleaseSpotRsp(cmdRsp);
        else if(cmdRsp.cmd().equalsIgnoreCase("parkKloudFindSpots") == true)
            prcsFindSpotsRsp(cmdRsp);
        else if(cmdRsp.cmd().equalsIgnoreCase("parkKloudGetRegisteredSpots") == true)
            prcsGetRegisteredSpotsRsp(cmdRsp);
        else if(cmdRsp.cmd().equalsIgnoreCase("parkKloudGetImagesDir") == true)
            prcsGetImagesDirRsp(cmdRsp);
        else if(cmdRsp.cmd().equalsIgnoreCase("parkKloudLogToFile") == true)
            prcsLogToFileRsp(cmdRsp);
    }

    public void prcsRegisterSpotRsp(CmdRsp cmdRsp) {
        DataKey dataKey = cmdRsp.dataKey();
        if(dataKey.curMrkr() == null) return;
        String rsp = cmdRsp.srvrRsp();
        if((rsp == null) || (rsp.isEmpty() == true)) return;
        String[] lines = rsp.split("\r\n");
        for(String line : lines) {
            if(line.contains("Registration successful. Spot ID ") == false) continue;
            String spotId = line.replace("Registration successful. Spot ID ", "").trim();
            dataKey.curMrkr().setIcon(dataKey.rgdMrkrBmd());
            dataKey.curMrkr().setTag(spotId); dataKey.addRegdSpot(dataKey.curMrkr());
            Toast.makeText(dataKey.context(), line, Toast.LENGTH_LONG).show();
            break;
        }
    }

    public void prcsWithdrawSpotRsp(CmdRsp cmdRsp) {
        DataKey dataKey = cmdRsp.dataKey();
        String rsp = cmdRsp.srvrRsp();
        if((rsp == null) || (rsp.isEmpty() == true)) return; if(dataKey.curMrkr() == null) return;
        String[] lines = rsp.split("\r\n");
        String mtchr = "Spot " + (String)(dataKey.curMrkr().getTag()) + " withdrawn from rentals.";
        for(String line : lines) {
            if(line.contains(mtchr) == false) continue;
            dataKey.curMrkr().setIcon(dataKey.newMrkrBmd());
            dataKey.curMrkr().setTag(""); dataKey.delRegdSpot(dataKey.curMrkr());
            Toast.makeText(dataKey.context(), line, Toast.LENGTH_LONG).show();
            break;
        }
    }

    public void prcsOccupySpotRsp(CmdRsp cmdRsp) {
        DataKey dataKey = cmdRsp.dataKey();
        String rsp = cmdRsp.srvrRsp(); if((rsp == null) || (rsp.isEmpty() == true)) return;
        String[] lines = rsp.split("\r\n");
        String sucs = "<success>", serr  = "<error>", sfail = "<failure>";
        for(String line : lines) {
            if(line.trim().startsWith(serr) == true) {
                String s = getAttrVal(line, "error");
                if((s != null) && (s.isEmpty() == false))
                    Toast.makeText(dataKey.context(), s, Toast.LENGTH_LONG).show();
                break;
            }

            if(line.trim().startsWith(sfail) == true) {
                String s = getAttrVal(line, "failure");
                if((s != null) && (s.isEmpty() == false))
                    Toast.makeText(dataKey.context(), s, Toast.LENGTH_LONG).show();
                break;
            }

            if(line.trim().startsWith(sucs) == false) continue;

            String s = getAttrVal(line, "success"); if((s == null) || (s.isEmpty() == true))    break;
            String id  = (s != null) ? getAttrVal(s, "spotId")      : "";
            String msg = (s != null) ? getAttrVal(s, "message") : "";
            String lbl = (s != null) ? getAttrVal(s, "label")   : "";
            Marker m   = ((id != null) && (id.isEmpty() == false)) ? dataKey.findParkMrkr(id) : null;
            if(m != null) {m.setIcon(dataKey.rgdMrkrBmd()); saveOccupiedSpot(dataKey, id, lbl);}
            if((msg != null) && (msg.isEmpty() == false))
                Toast.makeText(dataKey.context(), msg, Toast.LENGTH_LONG).show();
            break;
        }
    }

    public void prcsReleaseSpotRsp(CmdRsp cmdRsp) {
        DataKey dataKey = cmdRsp.dataKey();
        String rsp = cmdRsp.srvrRsp(); if((rsp == null) || (rsp.isEmpty() == true)) return;
        String[] lines = rsp.split("\r\n");
        String sucs = "<success>", serr  = "<error>", sfail = "<failure>";
        for(String line : lines) {
            if(line.trim().startsWith(serr) == true) {
                String s = getAttrVal(line, "error");
                if((s != null) && (s.isEmpty() == false))
                    Toast.makeText(dataKey.context(), s, Toast.LENGTH_LONG).show();
                break;
            }

            if(line.trim().startsWith(sfail) == true) {
                String s = getAttrVal(line, "failure");
                if((s != null) && (s.isEmpty() == false)) {
                    Toast.makeText(dataKey.context(), s, Toast.LENGTH_LONG).show();
                }
                eraseSavedOccupiedSpot(dataKey);
                break;
            }

            if(line.trim().startsWith(sucs) == false) continue;

            String s = getAttrVal(line, "success"); if((s == null) || (s.isEmpty() == true))    break;
            String id  = (s != null) ? getAttrVal(s, "spotId")      : "";
            String msg = (s != null) ? getAttrVal(s, "message") : "";
            String lbl = (s != null) ? getAttrVal(s, "label")   : "";
            Marker m   = ((id != null) && (id.isEmpty() == false)) ? dataKey.findParkMrkr(id) : null;
            if(m != null) m.setIcon(dataKey.newMrkrBmd());
            if((id != null) && (id.isEmpty() == false)) {
                m.setIcon(dataKey.newMrkrBmd());
                eraseSavedOccupiedSpot(dataKey);
            }
            if((msg != null) && (msg.isEmpty() == false))
                Toast.makeText(dataKey.context(), msg, Toast.LENGTH_LONG).show();
            break;
        }
    }

    public void prcsFindSpotsRsp(CmdRsp cmdRsp) {
        DataKey dataKey = cmdRsp.dataKey();
        String rsp = cmdRsp.srvrRsp();
        if((rsp == null) || (rsp.isEmpty() == true)) return;
        String[] lines = rsp.split("\r\n");
        String s1 = "<availableSpots>", s2 = "</availableSpots>";
        boolean start = false, stop = false;
        for(String line : lines) {
            if(line.trim().startsWith(s2) == true) break;
            if(line.trim().startsWith(s1) == true) {start = true; continue;}
            if(start == false) continue;
            String s = getAttrVal(line, "spot");
            if((s == null) || (s.isEmpty() == true)) continue;

            String id      = getAttrVal(s, "id");   if((id == null)   || (id.isEmpty()   == true)) continue;
            String latS    = getAttrVal(s, "lat");  if((latS == null) || (latS.isEmpty() == true)) continue;
            String lonS    = getAttrVal(s, "lon");  if((lonS == null) || (lonS.isEmpty() == true)) continue;
            String addr    = getAttrVal(s, "addr"); if(addr == null) addr = "";
            String label   = getAttrVal(s, "label");
            String beacon  = getAttrVal(s, "beacon");
            String imgFile = getAttrVal(s, "image");
            try {
                double lat = Double.valueOf(latS), lon = Double.valueOf(lonS);
                LatLng p = new LatLng(lat, lon);
                Marker m  = dataKey.appMap()
                    .addMarker(new MarkerOptions().position(p).icon(dataKey.newMrkrBmd()).title(addr));
                m.setTag(id); dataKey.addParkSpot(m, id, lat, lon, addr, label, beacon, imgFile);
            }
            catch(NumberFormatException nfe) {continue;}
        }
    }

    public void prcsGetRegisteredSpotsRsp(CmdRsp cmdRsp) {
        DataKey dataKey = cmdRsp.dataKey();
        String rsp = cmdRsp.srvrRsp();
        if((rsp == null) || (rsp.isEmpty() == true)) return;
        String[] lines = rsp.split("\r\n");
        String s1 = "<registeredSpots>", s2 = "</registeredSpots>";
        boolean start = false, stop = false;
        for(String line : lines) {
            if(line.trim().startsWith(s2) == true) break;
            if(line.trim().startsWith(s1) == true) {start = true; continue;}
            if(start == false) continue;
            String s = getAttrVal(line, "regdSpot");
            if((s == null) || (s.isEmpty() == true)) continue;

            String id    = getAttrVal(s, "id");  if((id == null)   || (id.isEmpty()   == true)) continue;
            String latS  = getAttrVal(s, "lat"); if((latS == null) || (latS.isEmpty() == true)) continue;
            String lonS  = getAttrVal(s, "lon"); if((lonS == null) || (lonS.isEmpty() == true)) continue;
            String addr  = getAttrVal(s, "addr"); if(addr == null) addr = "";
            String label = getAttrVal(s, "label");
            try {
                LatLng p = new LatLng(Double.valueOf(latS), Double.valueOf(lonS));
                Marker m  = dataKey.appMap()
                    .addMarker(new MarkerOptions().position(p).icon(dataKey.rgdMrkrBmd()).title(addr));
                m.setTag(id); dataKey.addRegdSpot(m);
            }
            catch(NumberFormatException nfe) {continue;}
        }
    }

    public void prcsGetImagesDirRsp(CmdRsp cmdRsp) {
        DataKey dataKey = cmdRsp.dataKey();
        String rsp = cmdRsp.srvrRsp(); if((rsp == null) || (rsp.isEmpty() == true)) return;
        String s1  = "<imagesDir>", s2  = "</imagesDir>";
        int    len = s1.length();
        int p1 = rsp.indexOf(s1);           if(p1 < 0) return;
        int p2 = rsp.indexOf(s2, p1 + len); if(p2 < 0) return;
        String imgsDir = rsp.substring(p1+len, p2);
        if((imgsDir != null) && (imgsDir.isEmpty() == false)) dataKey.imgsDir(imgsDir);
    }

    public void prcsLogToFileRsp(CmdRsp cmdRsp) {
        LogCounter logCounter = cmdRsp.logCounter();
        if(logCounter != null) logCounter.count(logCounter.count() + 1);
    }

    private String getAttrVal(String inStr, String attr) {
        int len = ("<" + attr + ">").length();
        int p1 = inStr.indexOf("<" + attr + ">");      if(p1 < 0) return(null);
        int p2 = inStr.indexOf("</" + attr + ">", p1); if(p2 < 0) return(null);
        return(inStr.substring(p1+len, p2));
    }

    private void saveOccupiedSpot(DataKey dataKey, String spotId, String label) {
        String fl = dataKey.ocpdSpotFile();
        if((fl == null) || (fl.isEmpty() == true)) {
            Log.d("LOG: ", "no occupiedSpots file, unable to save last occupied spot");
            return;
        }
        OutFileHdlr ofh = new OutFileHdlr();
        if(ofh.open(dataKey.context(), fl, false) == false) {
            Log.d("LOG: ", "unable to open occupied spots file to save last occupied spot");
            return;
        }
        ofh.writeLine((spotId + "," + label));
        Log.d("LOG: ", "successfully saved last occupied spot");
        ofh.close();
    }

    private void eraseSavedOccupiedSpot(DataKey dataKey) {
        String fl = dataKey.ocpdSpotFile();
        if((fl == null) || (fl.isEmpty() == true)) return;
        OutFileHdlr ofh = new OutFileHdlr();
        if(ofh.open(dataKey.context(), fl, false) == false) {
            Log.d("LOG: ", "unable to open occupied spots file to erase"); return;
        }
        ofh.close();
        Log.d("LOG: ", "successfully erased saved last occupied spot");
    }
}
