package com.spotimyze.mobility.parking;

/**
 * Created by S.Rajesh Kumar on 4/17/2017.
 */
public class KloudSrvr {
    private static String srvrIp  = "192.168.1.109";
    //private static String srvrIp  = "vps121369.vps.ovh.ca";
    private static String portStr = "4000";
    private static int    port    = 4000;

    public static String srvrIp()            {return(srvrIp);}
    public static String portStr()           {return(portStr);}
    public static int    port()              {return(port);}
    public static void   port(int val)       {port = val;}
}
